using UnityEngine;
using TMPro;
using System.Globalization;

public class MatrixDisPlay : MonoBehaviour
{
    [System.Serializable]
    public class MatrixGroup
    {
        public string name;
        public TextMeshProUGUI[] textFields = new TextMeshProUGUI[16];
    }

    [Header("Matrix Display Groups")]
    public MatrixGroup[] matrixGroups = new MatrixGroup[4];

    // IK Script
    public IK ik;

    // Matrix
    private float[,] T01 = new float[4, 4];
    private float[,] T12 = new float[4, 4];
    private float[,] T23 = new float[4, 4];
    private float[,] T3e = new float[4, 4];

    void Start()
    {
        HomeMatrix();
        DisplayAllMatrices();
    }

    void Update()
    {
        // Home position button
        if (ik.UIShow == 2)
        {
            // Home position matrix
            HomeMatrix();
            // Update UI 
            DisplayAllMatrices();
            ik.UIShow = 0; 
        }

        // Update matrix display when ready to show 
        if (ik.UIShow == 1)
        {
            // Update matrices
            UpdateMatrixDisplay();
            // Update UI 
            DisplayAllMatrices();
            ik.UIShow = 0; 
        }
    }

    // Identity Matrix
    void InitializeIdentityMatrix(float[,] m)
    {
        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 4; c++)
                m[r, c] = (r == c) ? 1f : 0f;
    }

    // Home position button 
    void HomeMatrix()
    {
        InitializeIdentityMatrix(T01);
        InitializeIdentityMatrix(T12);
        InitializeIdentityMatrix(T23);
        InitializeIdentityMatrix(T3e);
    }

    // Update matrix display when ready to show 
    void UpdateMatrixDisplay()
    {
        float l1 = ik.l1;
        float l2 = ik.l2;
        float l3 = ik.l3;
        float q1Rad = ik.q1Rad;
        float q2Rad = ik.q2Rad;
        float q3Rad = ik.q3Rad;

        // T01 : a0=0,  theta1=q1
        {
            float c = Mathf.Cos(q1Rad);
            float s = Mathf.Sin(q1Rad);
            T01[0, 0] = c; T01[0, 1] = -s; T01[0, 2] = 0f; T01[0, 3] = 0f;
            T01[1, 0] = s; T01[1, 1] = c; T01[1, 2] = 0f; T01[1, 3] = 0f;
            T01[2, 0] = 0f; T01[2, 1] = 0f; T01[2, 2] = 1f; T01[2, 3] = 0f;
            T01[3, 0] = 0f; T01[3, 1] = 0f; T01[3, 2] = 0f; T01[3, 3] = 1f;
        }

        // T12 : a1=l1, theta2=q2
        {
            float c = Mathf.Cos(q2Rad);
            float s = Mathf.Sin(q2Rad);
            T12[0, 0] = c; T12[0, 1] = -s; T12[0, 2] = 0f; T12[0, 3] = l1 * c;
            T12[1, 0] = s; T12[1, 1] = c; T12[1, 2] = 0f; T12[1, 3] = l1 * s;
            T12[2, 0] = 0f; T12[2, 1] = 0f; T12[2, 2] = 1f; T12[2, 3] = 0f;
            T12[3, 0] = 0f; T12[3, 1] = 0f; T12[3, 2] = 0f; T12[3, 3] = 1f;
        }

        // T23 : a2=l2, theta3=q3
        {
            float c = Mathf.Cos(q3Rad);
            float s = Mathf.Sin(q3Rad);
            T23[0, 0] = c; T23[0, 1] = -s; T23[0, 2] = 0f; T23[0, 3] = l2 * c;
            T23[1, 0] = s; T23[1, 1] = c; T23[1, 2] = 0f; T23[1, 3] = l2 * s;
            T23[2, 0] = 0f; T23[2, 1] = 0f; T23[2, 2] = 1f; T23[2, 3] = 0f;
            T23[3, 0] = 0f; T23[3, 1] = 0f; T23[3, 2] = 0f; T23[3, 3] = 1f;
        }

        // T3e : a3=l3, theta4=0
        {
            T3e[0, 0] = 1f; T3e[0, 1] = 0f; T3e[0, 2] = 0f; T3e[0, 3] = l3;
            T3e[1, 0] = 0f; T3e[1, 1] = 1f; T3e[1, 2] = 0f; T3e[1, 3] = 0f;
            T3e[2, 0] = 0f; T3e[2, 1] = 0f; T3e[2, 2] = 1f; T3e[2, 3] = 0f;
            T3e[3, 0] = 0f; T3e[3, 1] = 0f; T3e[3, 2] = 0f; T3e[3, 3] = 1f;
        }
    }

    // Display all matrices to UI
    void DisplayAllMatrices()
    {
        if (matrixGroups.Length >= 4)
        {
            FillMatrixGroup(matrixGroups[0], T01);  // T01
            FillMatrixGroup(matrixGroups[1], T12);  // T12
            FillMatrixGroup(matrixGroups[2], T23);  // T23
            FillMatrixGroup(matrixGroups[3], T3e);  // T3e0
        }
    }

    // Fill matrix in UI (TextPro) 
    void FillMatrixGroup(MatrixGroup group, float[,] matrix)
    {
        int k = 0;
        for (int r = 0; r < 4; r++)
        {
            for (int c = 0; c < 4; c++)
            {
                if (k < group.textFields.Length && group.textFields[k] != null)
                {
                    string value = matrix[r, c].ToString("0.###", CultureInfo.InvariantCulture);
                    group.textFields[k].text = value;
                }
                k++;
            }
        }
    }
}