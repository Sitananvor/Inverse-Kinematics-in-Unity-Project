using UnityEngine;
using TMPro;
using System.Globalization;

public class MatrixDisPlay : MonoBehaviour
{
    [System.Serializable]
    public class MatrixGroup
    {
        public string name;
        public TextMeshProUGUI[] textFields = new TextMeshProUGUI[16];
    }

    [Header("Matrix Display Groups")]
    public MatrixGroup[] matrixGroups = new MatrixGroup[4];

    // IK Script
    public IK ik;

    // Matrix4x4 
    private Matrix4x4 T01;
    private Matrix4x4 T12;
    private Matrix4x4 T23;
    private Matrix4x4 T3e;

    void Start()
    {
        HomeMatrix();
        DisplayAllMatrices();
    }

    void Update()
    {
        // Home position button
        if (ik.UIShow == 2)
        {
            // Home position matrix
            HomeMatrix();
            // Update UI 
            DisplayAllMatrices();
            ik.UIShow = 0;
        }

        // Update matrix display when ready to show 
        if (ik.UIShow == 1)
        {
            // Update matrices
            UpdateMatrixDisplay();
            // Update UI 
            DisplayAllMatrices();
            ik.UIShow = 0;
        }
    }

    // Set all 4 matrices to Identity
    void HomeMatrix()
    {
        T01 = Matrix4x4.identity;
        T12 = Matrix4x4.identity;
        T23 = Matrix4x4.identity;
        T3e = Matrix4x4.identity;
    }

    // The D–H function 
    Matrix4x4 DH(float a, float alpha, float d, float theta)
    {
        float ca = Mathf.Cos(alpha);
        float sa = Mathf.Sin(alpha);
        float ct = Mathf.Cos(theta);
        float st = Mathf.Sin(theta);

        // m = [ cosθ  -sinθ*cosα   sinθ*sinα   a*cosθ
        //       sinθ   cosθ*cosα  -cosθ*sinα   a*sinθ
        //       0       sinα         cosα        d
        //       0        0            0         1 ]
        Matrix4x4 m = new Matrix4x4();
        m.SetRow(0, new Vector4(ct, -st * ca,  st * sa, a * ct));
        m.SetRow(1, new Vector4(st,  ct * ca, -ct * sa, a * st));
        m.SetRow(2, new Vector4(0f,      sa,       ca,      d));
        m.SetRow(3, new Vector4(0f,     0f,      0f,     1f));
        return m;
    }

    // Calculate the matrix from q1, q2, q3 and l1, l2, l3 of IK
    void UpdateMatrixDisplay()
    {
        float l1 = ik.l1;
        float l2 = ik.l2;
        float l3 = ik.l3;
        float q1Rad = ik.q1Rad;
        float q2Rad = ik.q2Rad;
        float q3Rad = ik.q3Rad;

        // T01 : a0 = 0, alpha0 = 0, d1 = 0, theta1 = q1
        T01 = DH(0f, 0f, 0f, q1Rad);

        // T12 : a1 = l1, alpha1 = 0, d2 = 0, theta2 = q2
        T12 = DH(l1, 0f, 0f, q2Rad);

        // T23 : a2 = l2, alpha2 = 0, d3 = 0, theta3 = q3
        T23 = DH(l2, 0f, 0f, q3Rad);

        // T3e : a3 = l3, alpha3 = 0, d4 = 0, theta4 = 0
        T3e = DH(l3, 0f, 0f, 0f);
    }

    // Display all matrices to UI
    void DisplayAllMatrices()
    {
        if (matrixGroups.Length >= 4)
        {
            FillMatrixGroup(matrixGroups[0], T01);  // T01
            FillMatrixGroup(matrixGroups[1], T12);  // T12
            FillMatrixGroup(matrixGroups[2], T23);  // T23
            FillMatrixGroup(matrixGroups[3], T3e);  // T3e
        }
    }

    // Fill matrix in UI (TextMeshPro) 
    void FillMatrixGroup(MatrixGroup group, Matrix4x4 matrix)
    {
        int k = 0;
        for (int r = 0; r < 4; r++)
        {
            for (int c = 0; c < 4; c++)
            {
                if (k < group.textFields.Length && group.textFields[k] != null)
                {
                    float v = matrix[r, c];
                    string value = v.ToString("0.###", CultureInfo.InvariantCulture);
                    group.textFields[k].text = value;
                }
                k++;
            }
        }
    }
}
