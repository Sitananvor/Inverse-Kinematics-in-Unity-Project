using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;

public class IK : MonoBehaviour
{
    [Header("Input Fields")]
    public TMP_InputField xf;
    public TMP_InputField yf;
    public TMP_InputField thetaf;
    public Toggle toggleElbowUp;
    public Toggle toggleElbowDown;

    [Header("Input Buttons")]
    public Button solveButton;
    public Button resetButton;

    [Header("Output IK")]
    public TextMeshProUGUI q1;
    public TextMeshProUGUI q2;
    public TextMeshProUGUI q3;

    [Header("Output Status")]
    public TextMeshProUGUI statusText;

    [Header("Link Lengths")]
    public float l1 = 1.5f;
    public float l2 = 2.5f;
    public float l3 = 2.0f;

    [Header("Joint Limits (deg)")]
    public float q1MinDeg = 0f;
    public float q1MaxDeg = 180f;
    public float q2MinDeg = -120f;
    public float q2MaxDeg = 120f;
    public float q3MinDeg = -135f;
    public float q3MaxDeg = 135f;

    [Header("Ground")]
    public Transform groundLine;

    [HideInInspector] public int UIShow = 0;    // 0=none, 1=show, 2=reset
    [HideInInspector] public int simShow = 0;   // 0=none, 1=show, 2=reset
    [HideInInspector] public float q1Rad, q2Rad, q3Rad;
    [HideInInspector] public float q1Deg, q2Deg, q3Deg;

    // Close form functions
    // FK by MDH Transformation Matrices 
    private Func<Matrix4x4> T01_MDH;
    private Func<Matrix4x4> T12_MDH;
    private Func<Matrix4x4> T23_MDH;
    private Func<Matrix4x4> T3E_MDH;
    private Func<Matrix4x4> T0E_MDH;

    // FK Geometric for verify IK
    private Func<float> FK_PositionX;
    private Func<float> FK_PositionY;
    private Func<float> FK_Theta;

    // Jacobian and det(J)
    private Func<float> J_dx_dq1;
    private Func<float> J_dx_dq2;
    private Func<float> J_dx_dq3;
    private Func<float> J_dy_dq1;
    private Func<float> J_dy_dq2;
    private Func<float> J_dy_dq3;
    private Func<float, float, float, float, float, float, float> J_Determinant;

    void Start()
    {
        BuildMDHClosedForm();
        solveButton.onClick.AddListener(OnSolveButtonClicked);
        resetButton.onClick.AddListener(OnResetButtonClicked);
    }

    // Close form building
    void BuildMDHClosedForm()
    {
        // MDH Transformation Matrices 
        // Standard MDH: T = Rz(θ) * Tz(d) * Tx(a) * Rx(α)
        T01_MDH = () =>
        {
            Matrix4x4 T = Matrix4x4.identity;
            float c1 = Mathf.Cos(q1Rad);
            float s1 = Mathf.Sin(q1Rad);
            T.m00 = c1; T.m01 = -s1; T.m02 = 0; T.m03 = 0;
            T.m10 = s1; T.m11 = c1; T.m12 = 0; T.m13 = 0;
            T.m20 = 0; T.m21 = 0; T.m22 = 1; T.m23 = 0;
            T.m30 = 0; T.m31 = 0; T.m32 = 0; T.m33 = 1;
            return T;
        };

        T12_MDH = () =>
        {
            Matrix4x4 T = Matrix4x4.identity;
            float c2 = Mathf.Cos(q2Rad);
            float s2 = Mathf.Sin(q2Rad);
            T.m00 = c2; T.m01 = -s2; T.m02 = 0; T.m03 = l1 * c2;
            T.m10 = s2; T.m11 = c2; T.m12 = 0; T.m13 = l1 * s2;
            T.m20 = 0; T.m21 = 0; T.m22 = 1; T.m23 = 0;
            T.m30 = 0; T.m31 = 0; T.m32 = 0; T.m33 = 1;
            return T;
        };

        T23_MDH = () =>
        {
            Matrix4x4 T = Matrix4x4.identity;
            float c3 = Mathf.Cos(q3Rad);
            float s3 = Mathf.Sin(q3Rad);
            T.m00 = c3; T.m01 = -s3; T.m02 = 0; T.m03 = l2 * c3;
            T.m10 = s3; T.m11 = c3; T.m12 = 0; T.m13 = l2 * s3;
            T.m20 = 0; T.m21 = 0; T.m22 = 1; T.m23 = 0;
            T.m30 = 0; T.m31 = 0; T.m32 = 0; T.m33 = 1;
            return T;
        };

        T3E_MDH = () =>
        {
            Matrix4x4 T = Matrix4x4.identity;
            T.m00 = 1; T.m01 = 0; T.m02 = 0; T.m03 = l3;
            T.m10 = 0; T.m11 = 1; T.m12 = 0; T.m13 = 0;
            T.m20 = 0; T.m21 = 0; T.m22 = 1; T.m23 = 0;
            T.m30 = 0; T.m31 = 0; T.m32 = 0; T.m33 = 1;
            return T;
        };

        // T0E = T01 * T12 * T23 * T3E
        T0E_MDH = () => T01_MDH() * T12_MDH() * T23_MDH() * T3E_MDH();

        // FK Geometric for verify
        FK_PositionX = () => l1 * Mathf.Cos(q1Rad) +
                              l2 * Mathf.Cos(q1Rad + q2Rad) +
                              l3 * Mathf.Cos(q1Rad + q2Rad + q3Rad);
        FK_PositionY = () => l1 * Mathf.Sin(q1Rad) +
                              l2 * Mathf.Sin(q1Rad + q2Rad) +
                              l3 * Mathf.Sin(q1Rad + q2Rad + q3Rad);
        FK_Theta = () => q1Rad + q2Rad + q3Rad;


        // Jacobian >> It's a planar 2D arm so we only use x,y from the kinematic equations and ignore z (motion is confined to the XY plane) and 
        // end-effector orientation theta = q1 + q2 + q3, so d(theta)/d(q1,q2,q3) = [1, 1, 1] in the Jacobian.
        J_dx_dq1 = () =>
        {
            float q12 = q1Rad + q2Rad;
            float q123 = q12 + q3Rad;
            return -l1 * Mathf.Sin(q1Rad) - l2 * Mathf.Sin(q12) - l3 * Mathf.Sin(q123);
        };
        J_dx_dq2 = () =>
        {
            float q12 = q1Rad + q2Rad;
            float q123 = q12 + q3Rad;
            return -l2 * Mathf.Sin(q12) - l3 * Mathf.Sin(q123);
        };
        J_dx_dq3 = () => -l3 * Mathf.Sin(q1Rad + q2Rad + q3Rad);
        J_dy_dq1 = () =>
        {
            float q12 = q1Rad + q2Rad;
            float q123 = q12 + q3Rad;
            return l1 * Mathf.Cos(q1Rad) + l2 * Mathf.Cos(q12) + l3 * Mathf.Cos(q123);
        };
        J_dy_dq2 = () =>
        {
            float q12 = q1Rad + q2Rad;
            float q123 = q12 + q3Rad;
            return l2 * Mathf.Cos(q12) + l3 * Mathf.Cos(q123);
        };
        J_dy_dq3 = () => l3 * Mathf.Cos(q1Rad + q2Rad + q3Rad);

        J_Determinant = (J00, J01, J02, J10, J11, J12) =>
            J00 * (J11 - J12) - J01 * (J10 - J12) + J02 * (J10 - J11);
    }

    // Home Position
    void OnResetButtonClicked()
    {
        q1Rad = q2Rad = q3Rad = 0f;
        q1Deg = q2Deg = q3Deg = 0f;

        q1.text = "0"; q2.text = "0"; q3.text = "0";

        xf.text = ""; yf.text = ""; thetaf.text = "";

        toggleElbowUp.isOn = true;
        toggleElbowDown.isOn = false;

        statusText.text = "Status: System Ready";
        statusText.color = Color.white;

        UIShow = 2;
        simShow = 2;
        Debug.Log("Home Configuration");
    }

    void OnSolveButtonClicked()
    {
        if (xf.text == "" || yf.text == "" || thetaf.text == "")
        {
            statusText.text = $"Status: Please complete the entry for target";
            statusText.color = Color.red;
            return;
        }

        // Text to float
        float X = float.Parse(xf.text);
        float Y = float.Parse(yf.text);
        float thetaDeg = float.Parse(thetaf.text);

        // Check Reachability
        if (!CheckReachability(X, Y)) return;

        // Solve IK
        SolveIK_ClosedForm(X, Y, thetaDeg);
    }

    // Check Reachability
    bool CheckReachability(float X, float Y)
    {
        float distance = Mathf.Sqrt(X * X + Y * Y);
        float maxReach = l1 + l2 + l3;
        float minReach = Mathf.Abs(l1 - l2 - l3);

        if (distance > maxReach)
        {
            statusText.text = $"Status: Too far ({distance:F2} > {maxReach:F2})";
            statusText.color = Color.red;
            Debug.LogError("Too far");
            return false;
        }
        if (distance < minReach)
        {
            statusText.text = $"Status: Too close ({distance:F2} < {minReach:F2})";
            statusText.color = Color.red;
            Debug.LogError("Too close");
            return false;
        }
        Debug.Log($"Reachable");
        return true;
    }

    // Closed-Form IK Solution
    void SolveIK_ClosedForm(float X, float Y, float thetaDeg)
    {
        // Step 0: Deg to Rad
        float thetaRad = thetaDeg * Mathf.Deg2Rad;

        // Step 1: Compute Wrist Position
        float e1 = X - l3 * Mathf.Cos(thetaRad);
        float e2 = Y - l3 * Mathf.Sin(thetaRad);

        // Step 2: Solve q2 using Law of Cosines
        float cos_q2 = (e1 * e1 + e2 * e2 - l1 * l1 - l2 * l2) / (2f * l1 * l2);
        if (cos_q2 < -1f || cos_q2 > 1f)
        {
            statusText.text = $"Status: No solution (cos_q2={cos_q2:F3})";
            statusText.color = Color.red;
            Debug.LogError("cos(q2) out of range!");
            return;
        }

        // Step 3: q2 with Elbow Configuration
        bool elbowUp = toggleElbowUp.isOn;
        cos_q2 = Mathf.Clamp(cos_q2, -1f, 1f);
        float sin_q2 = elbowUp ? -Mathf.Sqrt(1f - cos_q2 * cos_q2) : Mathf.Sqrt(1f - cos_q2 * cos_q2);
        q2Rad = Mathf.Atan2(sin_q2, cos_q2);
        Debug.Log($"Elbow: {(elbowUp ? "UP" : "DOWN")}, q2={q2Rad * Mathf.Rad2Deg:F2}°");

        // Step 4: Solve q1
        float k1 = l1 + l2 * Mathf.Cos(q2Rad);
        float k2 = l2 * Mathf.Sin(q2Rad);
        q1Rad = Mathf.Atan2(e2, e1) - Mathf.Atan2(k2, k1);
        Debug.Log($"q1={q1Rad * Mathf.Rad2Deg:F2}°");

        // Step 5: Solve q3
        q3Rad = thetaRad - q1Rad - q2Rad;
        Debug.Log($"q3={q3Rad * Mathf.Rad2Deg:F2}°");

        // Convert to Degrees
        q1Deg = q1Rad * Mathf.Rad2Deg;
        q2Deg = q2Rad * Mathf.Rad2Deg;
        q3Deg = q3Rad * Mathf.Rad2Deg;

        // Check Joint Limits
        if (q1Deg < q1MinDeg || q1Deg > q1MaxDeg)
        {
            statusText.text = $"Status: q1 limit exceeded ({q1Deg:F2}°)";
            statusText.color = Color.red;
            Debug.LogError("q1 limit exceeded");
            return;
        }
        if (q2Deg < q2MinDeg || q2Deg > q2MaxDeg)
        {
            statusText.text = $"Status: q2 limit exceeded ({q2Deg:F2}°)";
            statusText.color = Color.red;
            Debug.LogError("q2 limit exceeded");
            return;
        }
        if (q3Deg < q3MinDeg || q3Deg > q3MaxDeg)
        {
            statusText.text = $"Status: q3 limit exceeded ({q3Deg:F2}°)";
            statusText.color = Color.red;
            Debug.LogError("q3 limit exceeded");
            return;
        }

        // Check Ground Collision
        if (!CheckGroundCollision())
        {
            statusText.text = "Status: Collision with ground!";
            statusText.color = Color.red;
            return;
        }

        // Check Singularity
        if (!CheckSingularity())
        {
            statusText.text = "Status: Singularity!";
            statusText.color = Color.red;
            return;
        }

        // Verify IK by FK
        if (!VerifyFK_MDH(X, Y, thetaDeg))
        {
            statusText.text = "Status: Program calculation error. Sorry.";
            statusText.color = Color.red;
            return;
        }

        // Update Status
        statusText.text = "Status: Solution Found";
        statusText.color = new Color(0f, 0.65f, 0f);
        UIShow = 1;
        simShow = 1;

        // Update Output Texts
        q1.text = $"{q1Deg:F2}°";
        q2.text = $"{Mathf.Abs(q2Deg):F2}°";
        q3.text = $"{q3Deg:F2}°";

        Invoke("ResetSimShow", 3.2f);
    }

    // Check if any part of the arm goes below y = 0
    bool CheckGroundCollision()
    {
        float groundY = groundLine.position.y;

        // Check each joint position
        // Joint 1 at base (0,0) >> always safe
        // Joint 2
        float j2_x = l1 * Mathf.Cos(q1Rad);
        float j2_y = l1 * Mathf.Sin(q1Rad);
        // Joint 3
        float q12 = q1Rad + q2Rad;
        float j3_x = j2_x + l2 * Mathf.Cos(q12);
        float j3_y = j2_y + l2 * Mathf.Sin(q12);
        // End Effector
        float q123 = q12 + q3Rad;
        float ee_x = j3_x + l3 * Mathf.Cos(q123);
        float ee_y = j3_y + l3 * Mathf.Sin(q123);

        // Check y-coordinates against ground level
        float collisionTolerance = 0.01f;
        float minAllowedY = groundY + collisionTolerance;
        if (j2_y < minAllowedY)
        {
            Debug.LogWarning($"Joint 2 collision! Y = {j2_y:F3} < {minAllowedY:F3}");
            return false;
        }
        if (j3_y < minAllowedY)
        {
            Debug.LogWarning($"Joint 3 collision! Y = {j3_y:F3} < {minAllowedY:F3}");
            return false;
        }
        if (ee_y < minAllowedY)
        {
            Debug.LogWarning($"End-Effector collision! Y = {ee_y:F3} < {minAllowedY:F3}");
            return false;
        }
        return true;
    }

    // Check Ground Collision
    bool CheckSingularity()
    {
        float J00 = J_dx_dq1();
        float J01 = J_dx_dq2();
        float J02 = J_dx_dq3();
        float J10 = J_dy_dq1();
        float J11 = J_dy_dq2();
        float J12 = J_dy_dq3();

        float detJ = J_Determinant(J00, J01, J02, J10, J11, J12);
        Debug.Log($"det(J) = {detJ:F4}");

        float threshold = 0.0001f;
        if (Mathf.Abs(detJ) < threshold)
        {
            Debug.LogWarning($"Singularity: |det(J)| = {Mathf.Abs(detJ):F4}");
            return false;
        }
        Debug.Log($"No singularity");
        return true;
    }

    // Verify IK by FK with Geometric
    bool VerifyFK_MDH(float X, float Y, float thetaDeg)
    {
        // Geometric Closed-Form and replace q1Rad, q2Rad, q3Rad from calculated IK
        float px = FK_PositionX();
        float py = FK_PositionY();
        float theta = FK_Theta();
        Debug.Log($"FK: px={px:F4}, py={py:F4}, theta={theta:F2}");

        // Error Calculation
        float errorX = Mathf.Abs(px - X);
        float errorY = Mathf.Abs(py - Y);
        float errorTheta = Mathf.Abs(theta * Mathf.Rad2Deg - thetaDeg);
        Debug.Log($"Error: ΔX={errorX:F4}, ΔY={errorY:F4}, Δθ={errorTheta:F2}°");

        if (errorX < 0.001f && errorY < 0.001f && errorTheta < 0.01f)
        {
            Debug.Log("Verification passed");
            return true;
        }
        else
        {
            Debug.LogWarning("Verification failed");
            return false;
        }
    }

    void ResetSimShow() {simShow = 0;}
}