using UnityEngine;

public class GridDrawer : MonoBehaviour
{
    [Header("Grid Settings")]
    public float gridSpacing = 0.5f;   // 0.5 หน่วย = 1 เมตร
    public int leftExtent = 10;
    public int rightExtent = 9;
    public int topExtent = 13;

    public Color gridColor = new Color(0.5f, 0.8f, 1f, 0.6f);
    public Color axisColor = Color.black;

    [Header("Axis Arrow Settings")]
    public float arrowHeadSize = 0.3f;  // ขนาดหัวลูกศร

    private Material lineMaterial;

    void Start()
    {
        CreateLineMaterial();
    }

    void CreateLineMaterial()
    {
        if (!lineMaterial)
        {
            Shader shader = Shader.Find("Hidden/Internal-Colored");
            lineMaterial = new Material(shader);
            lineMaterial.hideFlags = HideFlags.HideAndDontSave;
            lineMaterial.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
            lineMaterial.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            lineMaterial.SetInt("_Cull", (int)UnityEngine.Rendering.CullMode.Off);
            lineMaterial.SetInt("_ZWrite", 0);
        }
    }

    void OnRenderObject()
    {
        if (!lineMaterial) CreateLineMaterial();
        lineMaterial.SetPass(0);

        GL.PushMatrix();

        // หมุน -90° ให้กริดหงายขึ้น
        Quaternion rot = Quaternion.Euler(-90f, 0f, 0f);
        Matrix4x4 matrix = Matrix4x4.TRS(transform.position, rot, Vector3.one);
        GL.MultMatrix(matrix);

        GL.Begin(GL.LINES);

        float left = -leftExtent * gridSpacing;
        float right = rightExtent * gridSpacing;
        float top = topExtent * gridSpacing;

        // ---------- เส้นแนวนอน (ขนาน X) เฉพาะครึ่งบน ----------
        for (int i = 0; i <= topExtent; i++)
        {
            float z = i * gridSpacing;
            GL.Color(i == 0 ? axisColor : gridColor);   // i == 0 = แกน X
            GL.Vertex3(left, 0, z);
            GL.Vertex3(right, 0, z);
        }

        // ---------- เส้นแนวตั้ง (ขนาน Y) ----------
        for (int i = -leftExtent; i <= rightExtent; i++)
        {
            float x = i * gridSpacing;
            GL.Color(i == 0 ? axisColor : gridColor);   // i == 0 = แกน Y
            GL.Vertex3(x, 0, 0);
            GL.Vertex3(x, 0, top);
        }

        // ---------- คำนวณความยาว 3/4 ของตารางด้านนั้น ----------
        float leftSpan = Mathf.Abs(left);   // ระยะจาก 0 ไปขอบซ้าย
        float topSpan = top;                // ระยะจาก 0 ไปขอบบน

        float xLength = leftSpan * 0.75f;   // 3/4 ของด้านซ้าย
        float yLength = topSpan * 0.75f;    // 3/4 ของด้านบน

        // ---------- แกน X (แดง) ยาว 3/4 ด้านซ้าย ----------
        GL.Color(Color.red);

        // ปลายแกน X ไปทางซ้าย
        Vector3 xEnd = new Vector3(-xLength, 0, 0);

        GL.Vertex3(0, 0, 0);
        GL.Vertex3(xEnd.x, xEnd.y, xEnd.z);

        // หัวลูกศร (TIP อยู่ที่ xEnd → ฐานหัวต้องอยู่ค่อนไปทางขวา)
        Vector3 xHead1 = xEnd + new Vector3(+arrowHeadSize, 0,  arrowHeadSize * 0.7f);
        Vector3 xHead2 = xEnd + new Vector3(+arrowHeadSize, 0, -arrowHeadSize * 0.7f);

        GL.Vertex3(xEnd.x, xEnd.y, xEnd.z);
        GL.Vertex3(xHead1.x, xHead1.y, xHead1.z);

        GL.Vertex3(xEnd.x, xEnd.y, xEnd.z);
        GL.Vertex3(xHead2.x, xHead2.y, xHead2.z);

        // ---------- แกน Y (น้ำเงิน) ยาว 3/4 ด้านบน ----------
        GL.Color(Color.blue);

        // ปลายแกน Y ขึ้นไปด้านบน (ใช้ z แทน y บนระนาบ)
        Vector3 yEnd = new Vector3(0, 0, yLength);

        GL.Vertex3(0, 0, 0);
        GL.Vertex3(yEnd.x, yEnd.y, yEnd.z);

        // หัวลูกศร Y (TIP = yEnd → ฐานอยู่ค่อนไปทางล่าง)
        Vector3 yHead1 = yEnd + new Vector3( arrowHeadSize * 0.7f, 0, -arrowHeadSize);
        Vector3 yHead2 = yEnd + new Vector3(-arrowHeadSize * 0.7f, 0, -arrowHeadSize);

        GL.Vertex3(yEnd.x, yEnd.y, yEnd.z);
        GL.Vertex3(yHead1.x, yHead1.y, yHead1.z);

        GL.Vertex3(yEnd.x, yEnd.y, yEnd.z);
        GL.Vertex3(yHead2.x, yHead2.y, yHead2.z);

        GL.End();
        GL.PopMatrix();
    }

    // ให้เห็นกริดใน Scene View ด้วย
    void OnDrawGizmos()
    {
        Matrix4x4 oldMatrix = Gizmos.matrix;

        Quaternion rot = Quaternion.Euler(-90f, 0f, 0f);
        Gizmos.matrix = Matrix4x4.TRS(transform.position, rot, Vector3.one);

        float left = -leftExtent * gridSpacing;
        float right = rightExtent * gridSpacing;
        float top = topExtent * gridSpacing;

        // แนวนอน (ครึ่งบน)
        for (int i = 0; i <= topExtent; i++)
        {
            float z = i * gridSpacing;
            Gizmos.color = (i == 0) ? axisColor : gridColor;
            Gizmos.DrawLine(new Vector3(left, 0, z),
                            new Vector3(right, 0, z));
        }

        // แนวตั้ง
        for (int i = -leftExtent; i <= rightExtent; i++)
        {
            float x = i * gridSpacing;
            Gizmos.color = (i == 0) ? axisColor : gridColor;
            Gizmos.DrawLine(new Vector3(x, 0, 0),
                            new Vector3(x, 0, top));
        }

        // ---------- ความยาว 3/4 ของด้านนั้น ----------
        float leftSpan = Mathf.Abs(left);
        float topSpan = top;

        float xLength = leftSpan * 0.75f;
        float yLength = topSpan * 0.75f;

        // แกน X (Gizmos) ยาว 3/4 ด้านซ้าย
        Gizmos.color = Color.red;
        Vector3 xEndG = new Vector3(-xLength, 0, 0);
        Gizmos.DrawLine(Vector3.zero, xEndG);

        Vector3 xHead1G = xEndG + new Vector3(+arrowHeadSize, 0,  arrowHeadSize * 0.7f);
        Vector3 xHead2G = xEndG + new Vector3(+arrowHeadSize, 0, -arrowHeadSize * 0.7f);
        Gizmos.DrawLine(xEndG, xHead1G);
        Gizmos.DrawLine(xEndG, xHead2G);

        // แกน Y (Gizmos) ยาว 3/4 ด้านบน
        Gizmos.color = Color.blue;
        Vector3 yEndG = new Vector3(0, 0, yLength);
        Gizmos.DrawLine(Vector3.zero, yEndG);

        Vector3 yHead1G = yEndG + new Vector3( arrowHeadSize * 0.7f, 0, -arrowHeadSize);
        Vector3 yHead2G = yEndG + new Vector3(-arrowHeadSize * 0.7f, 0, -arrowHeadSize);
        Gizmos.DrawLine(yEndG, yHead1G);
        Gizmos.DrawLine(yEndG, yHead2G);

        Gizmos.matrix = oldMatrix;
    }

    void OnDestroy()
    {
        if (lineMaterial)
        {
            DestroyImmediate(lineMaterial);
        }
    }
}
