using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;

public class Obstacle : MonoBehaviour
{
    [Header("Obstacle")]
    public GameObject obstaclePrefab;

    [Header("Grid Reference")]
    public GridDrawer gridDrawer;

    [Header("Input Fields")]
    public TMP_InputField xfObs;
    public TMP_InputField yfObs;

    [Header("Output Status")]
    public TextMeshProUGUI statusText;

    [HideInInspector] public int obstacleHas = 0;
    [HideInInspector] public GameObject instantObstacle;
    [HideInInspector] public float obstacleGridX = 0f;
    [HideInInspector] public float obstacleGridY = 0f;

    public void OnToggleChanged(bool isOn)
    {
        if (isOn)
        {
            // ตรวจสอบว่ากรอกข้อมูลครบหรือไม่
            if (xfObs.text == "" || yfObs.text == "")
            {
                statusText.text = $"Status: Please complete the entry for Obstacle";
                statusText.color = Color.red;
                return;
            }

            // อ่านค่าจาก Input Fields
            float spawnX = float.Parse(xfObs.text);
            float spawnY = float.Parse(yfObs.text);
            obstacleHas = 1;
            obstacleGridX = spawnX;
            obstacleGridY = spawnY;

            Debug.Log($"Input: ({spawnX:F2}, {spawnY:F2})");

            float spacing = gridDrawer.gridSpacing;

            // ใช้ Grid coordinate system โดยตรง:
            // Grid X (แกนสีแดงไปซ้าย) = World -X
            // Grid Y (แกนสีน้ำเงินขึ้นบน) = World +Y
            float obsWorldX = -spawnX * spacing;
            float obsWorldY = spawnY * spacing;

            Vector3 spawnPos = new Vector3(obsWorldX, obsWorldY, 0f);

            // Spawn obstacle
            instantObstacle = Instantiate(obstaclePrefab, spawnPos, Quaternion.identity);

            statusText.text = $"Status: Obstacle at ({spawnX:F1},{spawnY:F1})";
            statusText.color = Color.white;
        }
        else
        {
            obstacleGridX = 0f;
            obstacleGridY = 0f;
            RemoveObstacle();
            statusText.text = "Status: Obstacle removed";
            statusText.color = Color.white;
        }
    }

    public void RemoveObstacle()
    {
        obstacleHas = 0;
        if (instantObstacle != null)
        {
            Destroy(instantObstacle);
        }

        xfObs.text = "";
        yfObs.text = "";
    }
}