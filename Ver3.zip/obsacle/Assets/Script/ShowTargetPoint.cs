using UnityEngine;

public class ShowTargetPoint : MonoBehaviour
{
    [Header("TargetPoint")]
    public GameObject targetPointPrefab;

    [Header("Grid Reference")]
    public GridDrawer gridDrawer;

    [HideInInspector] public GameObject instantTargetPoint;

    public void targetPointShow(float spawnX, float spawnY)
    {
        float spacing = gridDrawer.gridSpacing;

        // ใช้ Grid coordinate system โดยตรง:
        // Grid X (แกนสีแดงไปซ้าย) = World -X
        // Grid Y (แกนสีน้ำเงินขึ้นบน) = World +Y
        float obsWorldX = -spawnX * spacing;
        float obsWorldY = spawnY * spacing;

        Vector3 spawnPos = new Vector3(obsWorldX, obsWorldY, -0.1f);

        // Spawn obstacle
        instantTargetPoint = Instantiate(targetPointPrefab, spawnPos, Quaternion.identity);
    }

    public void targetPointReset()
    {
        if (instantTargetPoint != null)
        {
            Destroy(instantTargetPoint);
        }
    }
}
