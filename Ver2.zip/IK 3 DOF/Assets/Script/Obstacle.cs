using UnityEngine;

public class Obstacle : MonoBehaviour
{
    [Header("Obstacle")]
    public GameObject obstaclePrefab;

    [Header("Grid Reference")]
    public GridDrawer gridDrawer;

    [Header("Target Position")]
    public float spawnX = 0f;
    public float spawnY = 0f;

    [HideInInspector] public int obstacleCount = 0;
    [HideInInspector] private GameObject instantObstacle;
    [HideInInspector] public Vector3 offset = new Vector3(-0.25f, 0.25f, 0f);

    public void OnToggleChanged(bool isOn)
    {
        if (isOn)
        {
            obstacleCount = 1;

            // Change unit
            float spacing = gridDrawer.gridSpacing;
            float x = -spawnX * spacing;
            float y = spawnY * spacing;

            // Position for instant prefab
            Vector3 spawnPos = new Vector3(x, y, 0f) + offset;
            // Instant prefab
            instantObstacle = Instantiate(obstaclePrefab, spawnPos, Quaternion.identity);
        }
        else
        {
            obstacleCount = 0;
            if (instantObstacle != null)
            {
                Destroy(instantObstacle);
            }
        }
    }
}