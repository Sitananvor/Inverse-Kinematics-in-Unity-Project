using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class PathPlanning : MonoBehaviour
{
    [Header("References")]
    public IK ikScript;
    public Obstacle obstacleScript;
    public GridDrawer gridDrawer;

    [Header("Cubic Joint Controllers")]
    public CubicJointController joint1Controller;
    public CubicJointController joint2Controller;
    public CubicJointController joint3Controller;

    [Header("A* Settings")]
    public float stepSizeDeg = 15f;
    public float obstacleRadius = 0.45f;
    public int maxIterations = 10000;
    public float goalTolerance = 0.01f;

    [Header("Optimization")]
    public bool useAdaptiveStep = true;
    public int maxNeighbors = 16;

    [Header("Obstacle Avoidance")]
    public float obstaclePenalty = 5.0f;
    public float safetyMargin = 0.3f;

    [Header("Cubic Trajectory Settings")]
    public float segmentMoveTime = 0.5f;  // เวลาเคลื่อนที่ระหว่าง waypoint (วินาที)
    public bool smoothTrajectory = true;   // เปิด/ปิด cubic trajectory

    [Header("Execution Control")]
    public bool lockIKDuringExecution = true; // ล็อค IK ระหว่างเคลื่อนที่

    // Variables
    private List<Vector3> pathJointAngles = new List<Vector3>();
    private int currentWaypointIndex = 0;
    public bool isExecutingPath = false;
    private Vector3 startJoints;
    private Vector3 goalJoints;

    private Vector2 cachedObstaclePos;
    private bool hasObstacleCache = false;

    // ===== Cubic Trajectory Variables =====
    private bool isMovingSegment = false;
    private float segmentTime = 0f;

    // Cubic coefficients สำหรับแต่ละ joint (a0, a1, a2, a3)
    private float[] q1Coeffs = new float[4];
    private float[] q2Coeffs = new float[4];
    private float[] q3Coeffs = new float[4];

    // Start และ End angles สำหรับ segment ปัจจุบัน
    private Vector3 segmentStartAngles;
    private Vector3 segmentEndAngles;

    // Node for A* Search
    private class Node
    {
        public Vector3 joints;
        public Node parent;
        public float gCost;
        public float hCost;
        public float fCost => gCost + hCost;

        public Node(Vector3 j, Node p, float g, float h)
        {
            joints = j;
            parent = p;
            gCost = g;
            hCost = h;
        }
    }

    void Update()
    {
        // อัพเดท Cubic Trajectory Motion
        if (isExecutingPath && isMovingSegment && smoothTrajectory)
        {
            UpdateCubicMotion();
        }
    }

    public void ResetSystem()
    {
        ClearVisualization();
        hasObstacleCache = false;
        cachedObstaclePos = Vector2.zero;
    }

    public bool CheckObstacleCollisionWithArm(Vector2 obstacleWorldPos, float radius)
    {
        float q1 = ikScript.q1Rad;
        float q2 = ikScript.q2Rad;
        float q3 = ikScript.q3Rad;

        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        var j2w = WorkspaceToWorld(j2);
        var j3w = WorkspaceToWorld(j3);
        var eew = WorkspaceToWorld(ee);

        bool collision = LineCircleIntersection(Vector2.zero, j2w, obstacleWorldPos, radius * safetyMargin) ||
                        LineCircleIntersection(j2w, j3w, obstacleWorldPos, radius * safetyMargin) ||
                        LineCircleIntersection(j3w, eew, obstacleWorldPos, radius * safetyMargin);

        if (collision)
        {
            Debug.LogWarning($"Obstacle collides with robot arm!");
        }

        return collision;
    }

    // ===== MAIN FUNCTION =====
    public void PlanPathFromIK(float goalX, float goalY, float goalThetaDeg)
    {
        ClearVisualization();

        // Cache obstacle
        if (obstacleScript != null && obstacleScript.obstacleHas > 0)
        {
            float obsGridX = obstacleScript.obstacleGridX;
            float obsGridY = obstacleScript.obstacleGridY;
            float spacing = gridDrawer.gridSpacing;

            cachedObstaclePos = new Vector2(-obsGridX * spacing, obsGridY * spacing);
            hasObstacleCache = true;

            if (CheckObstacleCollisionWithArm(cachedObstaclePos, obstacleRadius))
            {
                ikScript.statusText.text = "Status: Obstacle Collision - Change position or reset";
                ikScript.statusText.color = Color.red;
                Debug.LogError("[PATH] Obstacle collision detected - cannot proceed");
                return;
            }

            Debug.Log($"[PATH] Obstacle cached at ({cachedObstaclePos.x:F2}, {cachedObstaclePos.y:F2})");
        }
        else
        {
            hasObstacleCache = false;
            Debug.Log("[PATH] No obstacle detected");
        }

        // Start configuration
        startJoints = new Vector3(ikScript.q1Rad, ikScript.q2Rad, ikScript.q3Rad);
        Debug.Log($"[PATH] Start: q1={startJoints.x * Mathf.Rad2Deg:F1}° q2={startJoints.y * Mathf.Rad2Deg:F1}° q3={startJoints.z * Mathf.Rad2Deg:F1}°");

        // Goal configuration
        if (!ikScript.SolveIK_ClosedForm(goalX, goalY, goalThetaDeg))
        {
            ikScript.statusText.text = "Status: IK No Solution";
            ikScript.statusText.color = Color.red;
            return;
        }

        goalJoints = new Vector3(ikScript.q1Rad, ikScript.q2Rad, ikScript.q3Rad);
        Debug.Log($"[PATH] Goal: q1={goalJoints.x * Mathf.Rad2Deg:F1}° q2={goalJoints.y * Mathf.Rad2Deg:F1}° q3={goalJoints.z * Mathf.Rad2Deg:F1}°");

        // Run A*
        Debug.Log("[PATH] 🔍 Searching path...");
        if (RunAStar())
        {
            Debug.Log($"[PATH] ✓ Found path with {pathJointAngles.Count} waypoints");
            ExecutePath();
        }
        else
        {
            Debug.LogError("[PATH] ❌ Path not found - Moving to furthest safe point");
            if (pathJointAngles.Count > 0)
            {
                ExecutePath();
            }
            else
            {
                ikScript.statusText.text = "Status: No Path Found";
                ikScript.statusText.color = Color.red;
            }
        }
    }

    // ===== A* ALGORITHM =====
    private bool RunAStar()
    {
        pathJointAngles.Clear();

        var openSet = new SortedSet<Node>(new NodeComparer());
        var openDict = new Dictionary<Vector3Int, Node>();
        var closedSet = new HashSet<Vector3Int>();

        var startNode = new Node(startJoints, null, 0f, Heuristic(startJoints, goalJoints));
        openSet.Add(startNode);
        openDict[Discretize(startJoints)] = startNode;

        int iterations = 0;
        var bestNode = startNode;
        float bestDist = float.MaxValue;

        while (openSet.Count > 0 && iterations < maxIterations)
        {
            iterations++;

            var current = openSet.Min;
            openSet.Remove(current);

            var currentDisc = Discretize(current.joints);
            openDict.Remove(currentDisc);

            float distToGoal = Vector3.Distance(current.joints, goalJoints);
            if (distToGoal < bestDist)
            {
                bestDist = distToGoal;
                bestNode = current;
            }

            if (distToGoal < goalTolerance)
            {
                Debug.Log($"[PATH] ✓ Reached goal in {iterations} iterations");
                ReconstructPath(current);
                return true;
            }

            closedSet.Add(currentDisc);

            // Adaptive step size
            float stepSize = stepSizeDeg;
            if (useAdaptiveStep)
            {
                float factor = Mathf.Clamp01(distToGoal / 1.5f);
                stepSize = Mathf.Lerp(8f, stepSizeDeg, factor);
            }

            var neighbors = GetNeighborsImproved(current.joints, stepSize);

            foreach (var neighbor in neighbors)
            {
                var neighborDisc = Discretize(neighbor);

                if (closedSet.Contains(neighborDisc))
                    continue;

                if (!IsValid(neighbor))
                    continue;

                float moveCost = Vector3.Distance(current.joints, neighbor);
                float gCost = current.gCost + moveCost;

                float hCost = HeuristicWithObstacle(neighbor, goalJoints);

                if (openDict.TryGetValue(neighborDisc, out var existing))
                {
                    if (gCost < existing.gCost)
                    {
                        openSet.Remove(existing);
                        existing.gCost = gCost;
                        existing.hCost = hCost;
                        existing.parent = current;
                        openSet.Add(existing);
                    }
                }
                else
                {
                    var newNode = new Node(neighbor, current, gCost, hCost);
                    openSet.Add(newNode);
                    openDict[neighborDisc] = newNode;
                }
            }
        }

        if (bestNode != startNode)
        {
            float distFromStart = Vector3.Distance(bestNode.joints, startJoints);
            if (distFromStart > 0.1f)
            {
                Debug.LogWarning($"[PATH] ⚠ Using partial path (reached {bestDist:F3}m from goal)");
                ReconstructPath(bestNode);
                string reason = GetInvalidReason(goalJoints);
                ikScript.statusText.text = $"Status: Partial Path - {reason}";
                ikScript.statusText.color = Color.yellow;
                return false;
            }
        }

        return false;
    }

    private class NodeComparer : IComparer<Node>
    {
        public int Compare(Node x, Node y)
        {
            if (x == null || y == null) return x == null ? 1 : -1;
            int f = x.fCost.CompareTo(y.fCost);
            if (f != 0) return f;
            int h = x.hCost.CompareTo(y.hCost);
            if (h != 0) return h;
            return x.GetHashCode().CompareTo(y.GetHashCode());
        }
    }

    // ===== HEURISTIC =====
    private float Heuristic(Vector3 from, Vector3 to)
    {
        return Vector3.Distance(from, to);
    }

    private float HeuristicWithObstacle(Vector3 config, Vector3 goal)
    {
        float baseCost = Vector3.Distance(config, goal);

        if (!hasObstacleCache)
            return baseCost * 1.1f;

        float minDistToObstacle = GetMinDistanceToObstacle(config);

        float obstacleCost = 0f;
        if (minDistToObstacle < obstacleRadius * safetyMargin * 2f)
        {
            float proximity = 1f - Mathf.Clamp01(minDistToObstacle / (obstacleRadius * safetyMargin * 2f));
            obstacleCost = proximity * obstaclePenalty;
        }

        return baseCost * 1.1f + obstacleCost;
    }

    private float GetMinDistanceToObstacle(Vector3 joints)
    {
        if (!hasObstacleCache)
            return float.MaxValue;

        float q1 = joints.x, q2 = joints.y, q3 = joints.z;

        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        var j2w = WorkspaceToWorld(j2);
        var j3w = WorkspaceToWorld(j3);
        var eew = WorkspaceToWorld(ee);

        float dist1 = DistanceToLineSegment(Vector2.zero, j2w, cachedObstaclePos);
        float dist2 = DistanceToLineSegment(j2w, j3w, cachedObstaclePos);
        float dist3 = DistanceToLineSegment(j3w, eew, cachedObstaclePos);

        return Mathf.Min(dist1, Mathf.Min(dist2, dist3));
    }

    private float DistanceToLineSegment(Vector2 start, Vector2 end, Vector2 point)
    {
        var line = end - start;
        float len = line.magnitude;
        if (len < 0.001f) return Vector2.Distance(start, point);

        float t = Mathf.Clamp01(Vector2.Dot(point - start, line) / (len * len));
        var projection = start + t * line;
        return Vector2.Distance(point, projection);
    }

    private Vector3Int Discretize(Vector3 config)
    {
        return new Vector3Int(
            Mathf.RoundToInt(config.x * Mathf.Rad2Deg * 2f),
            Mathf.RoundToInt(config.y * Mathf.Rad2Deg * 2f),
            Mathf.RoundToInt(config.z * Mathf.Rad2Deg * 2f)
        );
    }

    // ===== NEIGHBORS GENERATION =====
    private List<Vector3> GetNeighborsImproved(Vector3 config, float stepSize)
    {
        var neighbors = new List<Vector3>();
        float step = stepSize * Mathf.Deg2Rad;

        float[] steps = { -step, -step * 0.5f, 0f, step * 0.5f, step };

        foreach (float dq1 in steps)
        {
            foreach (float dq2 in steps)
            {
                foreach (float dq3 in steps)
                {
                    if (dq1 == 0 && dq2 == 0 && dq3 == 0) continue;

                    neighbors.Add(new Vector3(config.x + dq1, config.y + dq2, config.z + dq3));
                }
            }
        }

        return neighbors
            .OrderBy(n =>
            {
                float distToGoal = Vector3.Distance(n, goalJoints);
                float distToObs = hasObstacleCache ? GetMinDistanceToObstacle(n) : 100f;
                return distToGoal - (distToObs * 0.1f);
            })
            .Take(maxNeighbors)
            .ToList();
    }

    // ===== COLLISION CHECKING =====
    private bool IsValid(Vector3 joints)
    {
        float q1 = joints.x, q2 = joints.y, q3 = joints.z;
        float q1D = q1 * Mathf.Rad2Deg, q2D = q2 * Mathf.Rad2Deg, q3D = q3 * Mathf.Rad2Deg;

        if (q1D < ikScript.q1MinDeg || q1D > ikScript.q1MaxDeg) return false;
        if (q2D < ikScript.q2MinDeg || q2D > ikScript.q2MaxDeg) return false;
        if (q3D < ikScript.q3MinDeg || q3D > ikScript.q3MaxDeg) return false;

        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        if (j2.y < 0.01f || j3.y < 0.01f || ee.y < 0.01f) return false;

        if (hasObstacleCache)
        {
            var j2w = WorkspaceToWorld(j2);
            var j3w = WorkspaceToWorld(j3);
            var eew = WorkspaceToWorld(ee);

            float safeRadius = obstacleRadius * safetyMargin;

            if (LineCircleIntersection(Vector2.zero, j2w, cachedObstaclePos, safeRadius)) return false;
            if (LineCircleIntersection(j2w, j3w, cachedObstaclePos, safeRadius)) return false;
            if (LineCircleIntersection(j3w, eew, cachedObstaclePos, safeRadius)) return false;
        }

        return true;
    }

    // ตรวจสอบว่าทำไม goal configuration ถึงไม่ valid แล้วคืนเหตุผล
    private string GetInvalidReason(Vector3 joints)
    {
        float q1 = joints.x, q2 = joints.y, q3 = joints.z;
        float q1D = q1 * Mathf.Rad2Deg, q2D = q2 * Mathf.Rad2Deg, q3D = q3 * Mathf.Rad2Deg;

        // ตรวจ Joint Limits แบบละเอียด
        if (q1D < ikScript.q1MinDeg)
            return $"Joint 1 too low ({q1D:F1}° < {ikScript.q1MinDeg}°)";
        if (q1D > ikScript.q1MaxDeg)
            return $"Joint 1 too high ({q1D:F1}° > {ikScript.q1MaxDeg}°)";

        if (q2D < ikScript.q2MinDeg)
            return $"Joint 2 too low ({q2D:F1}° < {ikScript.q2MinDeg}°)";
        if (q2D > ikScript.q2MaxDeg)
            return $"Joint 2 too high ({q2D:F1}° > {ikScript.q2MaxDeg}°)";

        if (q3D < ikScript.q3MinDeg)
            return $"Joint 3 too low ({q3D:F1}° < {ikScript.q3MinDeg}°)";
        if (q3D > ikScript.q3MaxDeg)
            return $"Joint 3 too high ({q3D:F1}° > {ikScript.q3MaxDeg}°)";

        // ตรวจ Ground Collision
        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        if (j2.y < 0.01f)
            return $"Joint 2 hits ground (y={j2.y:F3}m)";
        if (j3.y < 0.01f)
            return $"Joint 3 hits ground (y={j3.y:F3}m)";
        if (ee.y < 0.01f)
            return $"End-effector hits ground (y={ee.y:F3}m)";

        // ตรวจ Obstacle
        if (hasObstacleCache)
        {
            var j2w = WorkspaceToWorld(j2);
            var j3w = WorkspaceToWorld(j3);
            var eew = WorkspaceToWorld(ee);

            float safeRadius = obstacleRadius * safetyMargin;

            if (LineCircleIntersection(Vector2.zero, j2w, cachedObstaclePos, safeRadius))
                return "Link 1 blocked by obstacle";
            if (LineCircleIntersection(j2w, j3w, cachedObstaclePos, safeRadius))
                return "Link 2 blocked by obstacle";
            if (LineCircleIntersection(j3w, eew, cachedObstaclePos, safeRadius))
                return "Link 3 blocked by obstacle";
        }

        return "Configuration invalid (unknown reason)";
    }

    private bool CheckCollisionNow(Vector3 joints)
    {
        if (!hasObstacleCache)
            return false;

        float q1 = joints.x, q2 = joints.y, q3 = joints.z;

        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        var j2w = WorkspaceToWorld(j2);
        var j3w = WorkspaceToWorld(j3);
        var eew = WorkspaceToWorld(ee);

        float safeRadius = obstacleRadius * safetyMargin;

        return LineCircleIntersection(Vector2.zero, j2w, cachedObstaclePos, safeRadius) ||
               LineCircleIntersection(j2w, j3w, cachedObstaclePos, safeRadius) ||
               LineCircleIntersection(j3w, eew, cachedObstaclePos, safeRadius);
    }

    // ===== PATH RECONSTRUCTION =====
    private void ReconstructPath(Node goalNode)
    {
        pathJointAngles.Clear();

        var current = goalNode;
        while (current != null)
        {
            pathJointAngles.Insert(0, current.joints);
            current = current.parent;
        }

        Debug.Log($"Reconstructed {pathJointAngles.Count} waypoints");
    }

    // ===== PATH EXECUTION WITH CUBIC TRAJECTORY =====
    private void ExecutePath()
    {
        ikScript.statusText.text = "Status: Executing";
        ikScript.statusText.color = Color.cyan;
        currentWaypointIndex = 0;
        isExecutingPath = true;

        // ล็อค IK script ไม่ให้อัปเดต
        if (lockIKDuringExecution && ikScript != null)
        {
            ikScript.enabled = false; // ปิด IK script ชั่วคราว
        }

        // Clear trajectory lines
        if (joint1Controller != null) joint1Controller.ClearTraject();
        if (joint2Controller != null) joint2Controller.ClearTraject();
        if (joint3Controller != null) joint3Controller.ClearTraject();

        // ปิด CubicJointControllers ระหว่าง path planning
        if (joint1Controller != null)
        {
            joint1Controller.ClearTraject();
            joint1Controller.enabled = false;
        }
        if (joint2Controller != null)
        {
            joint2Controller.ClearTraject();
            joint2Controller.enabled = false;
        }
        if (joint3Controller != null)
        {
            joint3Controller.ClearTraject();
            joint3Controller.enabled = false;
        }

        StartNextSegment();
    }

    /// <summary>
    /// เริ่มการเคลื่อนที่ไปยัง waypoint ถัดไป
    /// </summary>
    private void StartNextSegment()
    {
        if (!isExecutingPath || currentWaypointIndex >= pathJointAngles.Count)
        {
            // จบการเคลื่อนที่
            FinishPath();
            return;
        }

        // ตรวจสอบ collision ก่อนเคลื่อนที่
        var targetJoints = pathJointAngles[currentWaypointIndex];
        if (CheckCollisionNow(targetJoints))
        {
            isExecutingPath = false;
            isMovingSegment = false;
            ikScript.statusText.text = "Status: Collision Detected - Stopped";
            ikScript.statusText.color = Color.red;
            Debug.LogWarning($"Collision at waypoint {currentWaypointIndex}");
            return;
        }

        // กำหนด start และ end angles สำหรับ segment นี้
        segmentStartAngles = new Vector3(ikScript.q1Rad, ikScript.q2Rad, ikScript.q3Rad);
        segmentEndAngles = targetJoints;

        // คำนวณ cubic coefficients สำหรับแต่ละ joint
        ComputeCubicCoefficients(segmentStartAngles.x, segmentEndAngles.x, q1Coeffs);
        ComputeCubicCoefficients(segmentStartAngles.y, segmentEndAngles.y, q2Coeffs);
        ComputeCubicCoefficients(segmentStartAngles.z, segmentEndAngles.z, q3Coeffs);

        // อัพเดท status
        ikScript.statusText.text = $"Status: Executing ({currentWaypointIndex + 1}/{pathJointAngles.Count})";
        ikScript.statusText.color = Color.cyan;

        // เริ่มเคลื่อนที่
        segmentTime = 0f;
        isMovingSegment = true;

        Debug.Log($"[CUBIC] Segment {currentWaypointIndex}: " +
                  $"q1: {segmentStartAngles.x * Mathf.Rad2Deg:F1}° → {segmentEndAngles.x * Mathf.Rad2Deg:F1}° | " +
                  $"q2: {segmentStartAngles.y * Mathf.Rad2Deg:F1}° → {segmentEndAngles.y * Mathf.Rad2Deg:F1}° | " +
                  $"q3: {segmentStartAngles.z * Mathf.Rad2Deg:F1}° → {segmentEndAngles.z * Mathf.Rad2Deg:F1}°");
    }

    /// <summary>
    /// คำนวณ Cubic Polynomial Coefficients
    /// Boundary conditions: θ(0)=θ₀, θ(tf)=θf, θ̇(0)=0, θ̇(tf)=0
    /// θ(t) = a0 + a1*t + a2*t² + a3*t³
    /// </summary>
    private void ComputeCubicCoefficients(float startAngle, float endAngle, float[] coeffs)
    {
        float tf = segmentMoveTime;
        float tf2 = tf * tf;
        float tf3 = tf2 * tf;

        coeffs[0] = startAngle;                              // a0
        coeffs[1] = 0f;                                      // a1 (velocity = 0 at start)
        coeffs[2] = 3f * (endAngle - startAngle) / tf2;      // a2
        coeffs[3] = -2f * (endAngle - startAngle) / tf3;     // a3
    }

    /// <summary>
    /// คำนวณมุมจาก Cubic Polynomial ณ เวลา t
    /// </summary>
    private float EvaluateCubic(float[] coeffs, float t)
    {
        return coeffs[0] + coeffs[1] * t + coeffs[2] * t * t + coeffs[3] * t * t * t;
    }

    /// <summary>
    /// อัพเดทการเคลื่อนที่ตาม Cubic Trajectory (เรียกจาก Update)
    /// </summary>
    private void UpdateCubicMotion()
    {
        // เพิ่มเวลา
        segmentTime += Time.deltaTime;

        // ตรวจสอบว่าถึงจุดสิ้นสุด segment หรือยัง
        if (segmentTime >= segmentMoveTime)
        {
            segmentTime = segmentMoveTime;
            isMovingSegment = false;

            // ตั้งค่ามุมสุดท้ายให้ตรงพอดี
            SetJointAngles(segmentEndAngles);

            // ไป waypoint ถัดไป
            currentWaypointIndex++;
            StartNextSegment();
            return;
        }

        // คำนวณมุมปัจจุบันจาก cubic polynomial
        float q1 = EvaluateCubic(q1Coeffs, segmentTime);
        float q2 = EvaluateCubic(q2Coeffs, segmentTime);
        float q3 = EvaluateCubic(q3Coeffs, segmentTime);

        // ตรวจสอบ collision ระหว่างเคลื่อนที่
        Vector3 currentJoints = new Vector3(q1, q2, q3);
        if (CheckCollisionNow(currentJoints))
        {
            isExecutingPath = false;
            isMovingSegment = false;
            ikScript.statusText.text = "Status: Collision During Motion - Stopped";
            ikScript.statusText.color = Color.red;
            Debug.LogWarning($"Collision during cubic motion at t={segmentTime:F3}");
            return;
        }

        // อัพเดทมุมไปยัง IK script
        SetJointAngles(currentJoints);
    }

    /// <summary>
    /// ตั้งค่ามุม joints ไปยัง IK script
    /// </summary>
    private void SetJointAngles(Vector3 joints)
    {
        ikScript.q1Rad = joints.x;
        ikScript.q2Rad = joints.y;
        ikScript.q3Rad = joints.z;
        ikScript.q1Deg = joints.x * Mathf.Rad2Deg;
        ikScript.q2Deg = joints.y * Mathf.Rad2Deg;
        ikScript.q3Deg = joints.z * Mathf.Rad2Deg;

        // อัพเดท UI text
        ikScript.q1.text = $"{ikScript.q1Deg:F1}°";
        ikScript.q2.text = $"{ikScript.q2Deg:F1}°";
        ikScript.q3.text = $"{ikScript.q3Deg:F1}°";

        // ทริกเกอร์การแสดงผล
        ikScript.UIShow = 1;
        ikScript.simShow = 1;
    }

    /// <summary>
    /// จบการเคลื่อนที่ทั้งหมด
    private void FinishPath()
    {
        isExecutingPath = false;
        isMovingSegment = false;

        // ปลดล็อค IK script
        if (lockIKDuringExecution && ikScript != null)
        {
            ikScript.enabled = true;
        }

        if (pathJointAngles.Count > 0)
        {
            float distToGoal = Vector3.Distance(pathJointAngles[pathJointAngles.Count - 1], goalJoints);
            if (distToGoal < goalTolerance * 2f)
            {
                ikScript.statusText.text = "Status: Solution Found";
                ikScript.statusText.color = Color.green;
                Debug.Log("[PATH] ✓ Path execution completed successfully!");
            }
            else
            {
                string reason = GetInvalidReason(goalJoints);
                ikScript.statusText.text = $"Status: Partial Path - {reason}";
                ikScript.statusText.color = Color.yellow;
                Debug.Log($"[PATH] ⚠ Path execution completed (partial path)");
            }
        }

        // เปิด CubicJointControllers กลับมา
        if (joint1Controller != null) joint1Controller.enabled = true;
        if (joint2Controller != null) joint2Controller.enabled = true;
        if (joint3Controller != null) joint3Controller.enabled = true;
    }

    // ===== UTILITIES =====
    private Vector2 WorkspaceToWorld(Vector2 ws)
    {
        float spacing = gridDrawer.gridSpacing;
        return new Vector2(-ws.x * spacing, ws.y * spacing);
    }

    private bool LineCircleIntersection(Vector2 start, Vector2 end, Vector2 center, float radius)
    {
        var d = end - start;
        var f = start - center;

        float a = Vector2.Dot(d, d);
        float b = 2f * Vector2.Dot(f, d);
        float c = Vector2.Dot(f, f) - radius * radius;

        float disc = b * b - 4f * a * c;
        if (disc < 0) return false;

        disc = Mathf.Sqrt(disc);
        float t1 = (-b - disc) / (2f * a);
        float t2 = (-b + disc) / (2f * a);

        return (t1 >= 0 && t1 <= 1) || (t2 >= 0 && t2 <= 1);
    }

    private void ClearVisualization()
    {
        isExecutingPath = false;
        isMovingSegment = false;
        pathJointAngles.Clear();
        currentWaypointIndex = 0;
        segmentTime = 0f;
    }

    // ===== PUBLIC METHODS สำหรับ Debug =====

    /// <summary>
    /// หยุดการเคลื่อนที่ทันที
    /// </summary>
    public void StopExecution()
    {
        isExecutingPath = false;
        isMovingSegment = false;
        ikScript.statusText.text = "Status: Stopped";
        ikScript.statusText.color = Color.yellow;
    }

    /// <summary>
    /// คืนค่าจำนวน waypoints ทั้งหมด
    /// </summary>
    public int GetWaypointCount()
    {
        return pathJointAngles.Count;
    }

    /// <summary>
    /// คืนค่า waypoint index ปัจจุบัน
    /// </summary>
    public int GetCurrentWaypointIndex()
    {
        return currentWaypointIndex;
    }

    /// <summary>
    /// คืนค่า progress (0-1) ของ segment ปัจจุบัน
    /// </summary>
    public float GetSegmentProgress()
    {
        return segmentMoveTime > 0 ? segmentTime / segmentMoveTime : 0f;
    }
}