using UnityEngine;

public class Axis : MonoBehaviour
{
    [Header("Joint References")]
    [Tooltip("Joint 1")]
    public Transform joint1;

    [Tooltip("Joint 2")]
    public Transform joint2;

    [Tooltip("Joint 3")]
    public Transform joint3;

    [Header("Axis Settings")]
    [Tooltip("Axis length")]
    public float axisLength = 2f;

    [Tooltip("Axis thickness (not used with Gizmos)")]
    public float axisThickness = 0.05f;

    void OnDrawGizmos()
    {
        DrawAxes(joint1, "Joint 1");
        DrawAxes(joint2, "Joint 2");
        DrawAxes(joint3, "Joint 3");
    }

    void DrawAxes(Transform joint, string label)
    {
        if (joint == null) return;

        Vector3 position = joint.position;

        // X axis (red) → -forward
        Gizmos.color = Color.red;
        Vector3 xEnd = position - joint.forward * axisLength;
        Gizmos.DrawLine(position, xEnd);
        DrawArrow(position, -joint.forward, axisLength, Color.red);

        // Y axis (green) → right
        Gizmos.color = Color.green;
        Vector3 yEnd = position + joint.right * axisLength;
        Gizmos.DrawLine(position, yEnd);
        DrawArrow(position, joint.right, axisLength, Color.green);

        // Z axis (blue) → up
        Gizmos.color = Color.blue;
        Vector3 zEnd = position + joint.up * axisLength;
        Gizmos.DrawLine(position, zEnd);
        DrawArrow(position, joint.up, axisLength, Color.blue);

        // Joint center marker
        Gizmos.color = Color.white;
        Gizmos.DrawWireSphere(position, 0.1f);
    }

    void DrawArrow(Vector3 start, Vector3 direction, float length, Color color)
    {
        Gizmos.color = color;
        Vector3 end = start + direction * length;

        // Find perpendicular direction for arrow head
        Vector3 right = Vector3.Cross(direction, Vector3.up).normalized;
        if (right == Vector3.zero)
            right = Vector3.Cross(direction, Vector3.right).normalized;

        // Arrow head lines
        Vector3 arrowTip1 = end - direction * 0.2f + right * 0.1f;
        Vector3 arrowTip2 = end - direction * 0.2f - right * 0.1f;

        Gizmos.DrawLine(end, arrowTip1);
        Gizmos.DrawLine(end, arrowTip2);
    }
}
