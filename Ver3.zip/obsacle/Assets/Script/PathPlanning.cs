using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class PathPlanning : MonoBehaviour
{
    [Header("Script")]
    public IK ikScript; 
    public Obstacle obstacleScript;
    public GridDrawer gridDrawer; 

    [Header("A* Settings")]
    public float stepSizeDeg = 15f;     // Search step size (degrees)
    public float obstacleRadius = 0.5f; // Radius of obstacles
    public int maxIterations = 5000;    // Maximum number of loops for A*
    public float goalTolerance = 0.08f; // ความคลาดเคลื่อนที่ยอมรับได้ในการไปถึงเป้าหมาย

    [Header("Optimization")]
    public bool useAdaptiveStep = true; // ใช้การปรับขนาดก้าวเมื่อเข้าใกล้เป้าหมายหรือไม่
    public int maxNeighbors = 8;        // จำนวนเพื่อนบ้านสูงสุดที่คำนวณในแต่ละขั้นตอน

    [Header("Execution")]
    public float waypointDelay = 0.5f; // ระยะเวลารอระหว่างการไปยังแต่ละ waypoint

    // ตัวแปรภายใน
    private List<Vector3> pathJointAngles = new List<Vector3>(); // เก็บข้อมูลของมุมข้อต่อของแขน
    private int currentWaypointIndex = 0; // ตัวแปรเก็บตำแหน่งของ waypoint ที่กำลังดำเนินการ
    private bool isExecutingPath = false; // สถานะการดำเนินการเส้นทาง
    private Vector3 startJoints; // ตำแหน่งของข้อต่อเริ่มต้น
    private Vector3 goalJoints; // ตำแหน่งของข้อต่อเป้าหมาย

    // ตัวแปรสำหรับเก็บข้อมูลอุปสรรค
    private Vector2 cachedObstaclePos; // ตำแหน่งอุปสรรคที่เก็บไว้
    private bool hasObstacleCache = false; // สถานะว่าได้เก็บข้อมูลอุปสรรคไว้หรือไม่

    // Node สำหรับ A* Search
    private class Node
    {
        public Vector3 joints; // ตำแหน่งข้อต่อ
        public Node parent; // Node พ่อแม่ใน A* 
        public float gCost; // ค่าต้นทุนจากจุดเริ่มต้น
        public float hCost; // ค่าต้นทุนจากจุดเป้าหมาย
        public float fCost => gCost + hCost; // ค่า f = g + h

        // Constructor สำหรับสร้าง Node ใหม่
        public Node(Vector3 j, Node p, float g, float h)
        {
            joints = j;
            parent = p;
            gCost = g;
            hCost = h;
        }
    }

    // Reset Home (เรียกใช้จาก IK Script)
    public void ResetSystem()
    {
        ClearVisualization(); // เคลียร์การแสดงผล
        hasObstacleCache = false; // รีเซ็ตข้อมูลอุปสรรค
        cachedObstaclePos = Vector2.zero; // รีเซ็ตตำแหน่งอุปสรรค
    }

    // เช็คว่าอุปสรรคชนกับแขนกลหรือไม่
    public bool CheckObstacleCollisionWithArm(Vector2 obstacleWorldPos, float radius)
    {
        // ใช้ค่าปัจจุบันของข้อต่อในการคำนวณ
        float q1 = ikScript.q1Rad;
        float q2 = ikScript.q2Rad;
        float q3 = ikScript.q3Rad;

        // คำนวณตำแหน่งของแต่ละข้อต่อ
        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        // แปลงเป็น world space
        var j2w = WorkspaceToWorld(j2);
        var j3w = WorkspaceToWorld(j3);
        var eew = WorkspaceToWorld(ee);

        // เช็คชนกับแต่ละ link ของแขน
        bool collision = LineCircleIntersection(Vector2.zero, j2w, obstacleWorldPos, radius) ||
                        LineCircleIntersection(j2w, j3w, obstacleWorldPos, radius) ||
                        LineCircleIntersection(j3w, eew, obstacleWorldPos, radius);

        if (collision)
        {
            Debug.LogWarning($"[PATH] ⚠ Obstacle collides with robot arm!"); // แจ้งเตือนถ้าชน
        }

        return collision; // คืนค่าผลการตรวจสอบการชน
    }

    // ===== MAIN FUNCTION =====
    // ฟังก์ชันหลักในการวางแผนเส้นทางจากตำแหน่งเริ่มต้นถึงตำแหน่งเป้าหมาย
    public void PlanPathFromIK(float goalX, float goalY, float goalThetaDeg)
    {
        ClearVisualization(); // เคลียร์การแสดงผลของเส้นทางก่อน

        // อัปเดตข้อมูลอุปสรรค
        if (obstacleScript != null && obstacleScript.obstacleHas > 0)
        {
            // ดึงข้อมูลตำแหน่งของอุปสรรค
            float obsGridX = obstacleScript.obstacleGridX;
            float obsGridY = obstacleScript.obstacleGridY;
            float spacing = gridDrawer.gridSpacing;
            
            // เก็บตำแหน่งของอุปสรรคใน world space
            cachedObstaclePos = new Vector2(-obsGridX * spacing, obsGridY * spacing);
            hasObstacleCache = true;

            // เช็คการชนกับอุปสรรค
            if (CheckObstacleCollisionWithArm(cachedObstaclePos, obstacleRadius))
            {
                ikScript.statusText.text = "Status: ⚠ Obstacle blocks robot! Change position or reset"; // อัพเดตสถานะ
                ikScript.statusText.color = Color.red; // เปลี่ยนสีข้อความเป็นแดง
                Debug.LogError("[PATH] Obstacle collision detected - cannot proceed");
                return;
            }

            Debug.Log($"[PATH] Obstacle cached at ({cachedObstaclePos.x:F2}, {cachedObstaclePos.y:F2})");
        }
        else
        {
            hasObstacleCache = false;
            Debug.Log("[PATH] No obstacle detected");
        }

        // ตั้งค่าตำแหน่งเริ่มต้นจากค่าใน IK
        startJoints = new Vector3(ikScript.q1Rad, ikScript.q2Rad, ikScript.q3Rad);
        Debug.Log($"[PATH] Start: q1={startJoints.x*Mathf.Rad2Deg:F1}° q2={startJoints.y*Mathf.Rad2Deg:F1}° q3={startJoints.z*Mathf.Rad2Deg:F1}°");

        // คำนวณตำแหน่งเป้าหมาย
        if (!ikScript.SolveIK_ClosedForm(goalX, goalY, goalThetaDeg))
        {
            ikScript.statusText.text = "Status: IK Failed";
            ikScript.statusText.color = Color.red;
            return;
        }

        goalJoints = new Vector3(ikScript.q1Rad, ikScript.q2Rad, ikScript.q3Rad);
        Debug.Log($"[PATH] Goal: q1={goalJoints.x*Mathf.Rad2Deg:F1}° q2={goalJoints.y*Mathf.Rad2Deg:F1}° q3={goalJoints.z*Mathf.Rad2Deg:F1}°");

        // รัน A* เพื่อหาทาง
        Debug.Log("[PATH] 🔍 Searching path...");
        if (RunAStar())
        {
            Debug.Log($"[PATH] ✓ Found path with {pathJointAngles.Count} waypoints");
            ExecutePath();
        }
        else
        {
            ikScript.statusText.text = "Status: No Path Found";
            ikScript.statusText.color = Color.red;
            Debug.LogError("[PATH] ❌ Path not found");
        }
    }

    // ===== A* ALGORITHM =====
    private bool RunAStar()
    {
        pathJointAngles.Clear();

        var openSet = new SortedSet<Node>(new NodeComparer()); // สร้างชุด open set
        var openDict = new Dictionary<Vector3Int, Node>(); // เก็บ open set เป็น dictionary
        var closedSet = new HashSet<Vector3Int>(); // สร้างชุด closed set

        var startNode = new Node(startJoints, null, 0f, Heuristic(startJoints, goalJoints)); // เริ่มต้น Node
        openSet.Add(startNode);
        openDict[Discretize(startJoints)] = startNode;

        int iterations = 0; // ตัวแปรนับจำนวนการวนลูป
        var bestNode = startNode; // Node ที่ดีที่สุด
        float bestDist = float.MaxValue; // ระยะทางที่ดีที่สุด

        // เริ่มการค้นหาด้วย A*
        while (openSet.Count > 0 && iterations < maxIterations)
        {
            iterations++; // เพิ่มการวนลูป

            var current = openSet.Min; // เลือก Node ที่ดีที่สุด
            openSet.Remove(current);

            var currentDisc = Discretize(current.joints);
            openDict.Remove(currentDisc);

            float distToGoal = Vector3.Distance(current.joints, goalJoints); // คำนวณระยะห่างจากเป้าหมาย
            if (distToGoal < bestDist)
            {
                bestDist = distToGoal;
                bestNode = current;
            }

            if (distToGoal < goalTolerance)
            {
                Debug.Log($"[PATH] ✓ Reached goal in {iterations} iterations");
                ReconstructPath(current); // สร้างเส้นทางจาก Node ปัจจุบัน
                return true;
            }

            closedSet.Add(currentDisc); // เพิ่ม Node นี้ใน closed set

            float stepSize = stepSizeDeg;
            if (useAdaptiveStep)
            {
                // ปรับขนาดก้าวตามระยะห่างจากเป้าหมาย
                float factor = Mathf.Clamp01(distToGoal / 1.5f);
                stepSize = Mathf.Lerp(5f, stepSizeDeg, factor);
            }

            var neighbors = GetNeighborsOptimized(current.joints, stepSize); // หาเพื่อนบ้านที่ดีที่สุด
            
            foreach (var neighbor in neighbors)
            {
                var neighborDisc = Discretize(neighbor);
                
                if (closedSet.Contains(neighborDisc)) // ถ้าเพื่อนบ้านนี้อยู่ใน closed set ให้ข้ามไป
                    continue;

                if (!IsValid(neighbor)) // ถ้าไม่สามารถไปได้ให้ข้ามไป
                    continue;

                // คำนวณค่าต้นทุนการเดินทาง
                float moveCost = Vector3.Distance(current.joints, neighbor);
                float gCost = current.gCost + moveCost;
                float hCost = Heuristic(neighbor, goalJoints) * 1.1f;

                if (openDict.TryGetValue(neighborDisc, out var existing)) // เช็คถ้ามี Node นี้อยู่ใน open set แล้ว
                {
                    if (gCost < existing.gCost) // ถ้าค่าต้นทุนใหม่ดีกว่า
                    {
                        openSet.Remove(existing);
                        existing.gCost = gCost;
                        existing.parent = current;
                        openSet.Add(existing);
                    }
                }
                else
                {
                    var newNode = new Node(neighbor, current, gCost, hCost);
                    openSet.Add(newNode);
                    openDict[neighborDisc] = newNode;
                }
            }
        }

        if (bestDist < goalTolerance * 2f)
        {
            Debug.LogWarning($"[PATH] ⚠ Using best path (dist: {bestDist:F3})");
            ReconstructPath(bestNode);
            return true;
        }

        return false; // ไม่พบเส้นทาง
    }

    private class NodeComparer : IComparer<Node>
    {
        public int Compare(Node x, Node y)
        {
            if (x == null || y == null) return x == null ? 1 : -1;
            int f = x.fCost.CompareTo(y.fCost); // เปรียบเทียบ fCost
            if (f != 0) return f;
            int h = x.hCost.CompareTo(y.hCost); // เปรียบเทียบ hCost
            if (h != 0) return h;
            return x.GetHashCode().CompareTo(y.GetHashCode());
        }
    }

    private float Heuristic(Vector3 from, Vector3 to) => Vector3.Distance(from, to); // คำนวณ Heuristic (ระยะห่างระหว่างจุด)

    private Vector3Int Discretize(Vector3 config)
    {
        // แปลงค่ามุมเป็นหน่วยที่ละเอียดขึ้นเพื่อให้เหมาะสมกับการค้นหา A*
        return new Vector3Int(
            Mathf.RoundToInt(config.x * Mathf.Rad2Deg * 2f),
            Mathf.RoundToInt(config.y * Mathf.Rad2Deg * 2f),
            Mathf.RoundToInt(config.z * Mathf.Rad2Deg * 2f)
        );
    }

    // ===== NEIGHBORS GENERATION =====
    private List<Vector3> GetNeighborsOptimized(Vector3 config, float stepSize)
    {
        var neighbors = new List<Vector3>();
        float step = stepSize * Mathf.Deg2Rad;
        float[] steps = { -step, 0f, step };

        foreach (float dq1 in steps)
        {
            foreach (float dq2 in steps)
            {
                foreach (float dq3 in steps)
                {
                    int moving = (dq1 != 0 ? 1 : 0) + (dq2 != 0 ? 1 : 0) + (dq3 != 0 ? 1 : 0);
                    if (moving < 2) continue; // ถ้ากำลังเคลื่อนที่แค่หนึ่งข้อต่อ ข้ามไป

                    neighbors.Add(new Vector3(config.x + dq1, config.y + dq2, config.z + dq3));
                }
            }
        }

        return neighbors
            .OrderBy(n => Vector3.Distance(n, goalJoints)) // จัดเรียงตามระยะห่างจากเป้าหมาย
            .Take(maxNeighbors) // เลือกเฉพาะจำนวนเพื่อนบ้านสูงสุด
            .ToList();
    }

    // ===== COLLISION CHECKING =====
    private bool IsValid(Vector3 joints)
    {
        // ตรวจสอบการชนระหว่างข้อต่อและขอบเขตที่ตั้งไว้
        float q1 = joints.x, q2 = joints.y, q3 = joints.z;
        float q1D = q1 * Mathf.Rad2Deg, q2D = q2 * Mathf.Rad2Deg, q3D = q3 * Mathf.Rad2Deg;

        if (q1D < ikScript.q1MinDeg || q1D > ikScript.q1MaxDeg) return false;
        if (q2D < ikScript.q2MinDeg || q2D > ikScript.q2MaxDeg) return false;
        if (q3D < ikScript.q3MinDeg || q3D > ikScript.q3MaxDeg) return false;

        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        // ตรวจสอบการชนกับอุปสรรคที่บันทึกไว้
        if (j2.y < 0.01f || j3.y < 0.01f || ee.y < 0.01f) return false;

        if (hasObstacleCache)
        {
            var j2w = WorkspaceToWorld(j2);
            var j3w = WorkspaceToWorld(j3);
            var eew = WorkspaceToWorld(ee);
            
            if (LineCircleIntersection(Vector2.zero, j2w, cachedObstaclePos, obstacleRadius)) return false;
            if (LineCircleIntersection(j2w, j3w, cachedObstaclePos, obstacleRadius)) return false;
            if (LineCircleIntersection(j3w, eew, cachedObstaclePos, obstacleRadius)) return false;
        }

        return true; // ถ้าไม่มีการชน ให้ค่าผลลัพธ์เป็นจริง
    }

    private bool CheckCollisionNow(Vector3 joints)
    {
        if (!hasObstacleCache)
            return false;

        float q1 = joints.x, q2 = joints.y, q3 = joints.z;

        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        var j2w = WorkspaceToWorld(j2);
        var j3w = WorkspaceToWorld(j3);
        var eew = WorkspaceToWorld(ee);
        
        return LineCircleIntersection(Vector2.zero, j2w, cachedObstaclePos, obstacleRadius) ||
               LineCircleIntersection(j2w, j3w, cachedObstaclePos, obstacleRadius) ||
               LineCircleIntersection(j3w, eew, cachedObstaclePos, obstacleRadius);
    }

    // ===== PATH RECONSTRUCTION =====
    private void ReconstructPath(Node goalNode)
    {
        pathJointAngles.Clear();
        
        var current = goalNode;
        while (current != null)
        {
            pathJointAngles.Insert(0, current.joints); // เพิ่มจุด waypoint ลงใน path
            current = current.parent; // ขึ้นไปยัง Node ก่อนหน้า
        }

        if (Vector3.Distance(pathJointAngles[pathJointAngles.Count - 1], goalJoints) > 0.01f)
        {
            pathJointAngles.Add(goalJoints); // เพิ่มจุดเป้าหมายลงใน path ถ้ายังไม่อยู่ในเส้นทาง
        }

        Debug.Log($"[PATH] Reconstructed {pathJointAngles.Count} waypoints"); // แสดงจำนวนของ waypoints ที่คำนวณได้
    }

    // ===== PATH EXECUTION =====
    private void ExecutePath()
    {
        ikScript.statusText.text = "Status: Executing..."; // อัปเดตสถานะการทำงาน
        ikScript.statusText.color = Color.cyan;
        currentWaypointIndex = 0;
        isExecutingPath = true;
        ExecuteNextWaypoint(); // เริ่มการเคลื่อนที่ไปยัง waypoint ถัดไป
    }

    private void ExecuteNextWaypoint()
    {
        if (!isExecutingPath || currentWaypointIndex >= pathJointAngles.Count)
        {
            isExecutingPath = false;
            ikScript.statusText.text = "Status: Complete! ✓"; // แสดงข้อความเมื่อเสร็จสิ้น
            ikScript.statusText.color = Color.green;
            return;
        }

        var joints = pathJointAngles[currentWaypointIndex]; // ดึงค่า joints จาก waypoint

        // ตรวจสอบการชนก่อนเคลื่อนที่
        if (CheckCollisionNow(joints))
        {
            isExecutingPath = false;
            ikScript.statusText.text = "Status: ⚠ Collision! Stopped"; // แสดงข้อความเมื่อเกิดการชน
            ikScript.statusText.color = Color.red;
            Debug.LogWarning($"[PATH] ⚠ Collision at waypoint {currentWaypointIndex}"); // เตือนเมื่อมีการชน
            return;
        }

        // ปรับค่ามุมของแขนกล
        ikScript.q1Rad = joints.x;
        ikScript.q2Rad = joints.y;
        ikScript.q3Rad = joints.z;
        ikScript.q1Deg = joints.x * Mathf.Rad2Deg;
        ikScript.q2Deg = joints.y * Mathf.Rad2Deg;
        ikScript.q3Deg = joints.z * Mathf.Rad2Deg;

        // อัปเดตค่ามุมให้ UI
        ikScript.q1.text = $"{ikScript.q1Deg:F1}°";
        ikScript.q2.text = $"{ikScript.q2Deg:F1}°";
        ikScript.q3.text = $"{ikScript.q3Deg:F1}°";
        
        ikScript.statusText.text = $"Status: {currentWaypointIndex + 1}/{pathJointAngles.Count}"; // แสดงสถานะการทำงาน
        ikScript.statusText.color = Color.cyan;

        ikScript.UIShow = 1; // แสดง UI
        ikScript.simShow = 1; // แสดงการจำลอง

        currentWaypointIndex++; // เปลี่ยนไป waypoint ถัดไป

        if (currentWaypointIndex < pathJointAngles.Count)
            Invoke("ExecuteNextWaypoint", waypointDelay); // เลื่อนการทำงานไปยัง waypoint ถัดไป
        else
            Invoke("ShowCompletion", waypointDelay); // แสดงสถานะการทำงานเสร็จสิ้น
    }

    private void ShowCompletion()
    {
        ikScript.statusText.text = "Status: Complete! ✓"; // แสดงข้อความเมื่อการเคลื่อนที่เสร็จสิ้น
        ikScript.statusText.color = Color.green;
    }

    // ===== UTILITIES =====
    private Vector2 WorkspaceToWorld(Vector2 ws)
    {
        // แปลงจาก workspace coordinates ไปยัง world space
        float spacing = gridDrawer.gridSpacing;
        return new Vector2(-ws.x * spacing, ws.y * spacing);
    }

    private bool LineCircleIntersection(Vector2 start, Vector2 end, Vector2 center, float radius)
    {
        // ตรวจสอบการชนระหว่างเส้นและวงกลม
        var d = end - start;
        var f = start - center;

        float a = Vector2.Dot(d, d);
        float b = 2f * Vector2.Dot(f, d);
        float c = Vector2.Dot(f, f) - radius * radius;

        float disc = b * b - 4f * a * c;
        if (disc < 0) return false;

        disc = Mathf.Sqrt(disc);
        float t1 = (-b - disc) / (2f * a);
        float t2 = (-b + disc) / (2f * a);

        return (t1 >= 0 && t1 <= 1) || (t2 >= 0 && t2 <= 1); // ถ้ามีการชน ให้คืนค่า true
    }

    private void ClearVisualization()
    {
        // เคลียร์ข้อมูลการแสดงผลและการทำงาน
        isExecutingPath = false;
        CancelInvoke("ExecuteNextWaypoint");
        CancelInvoke("ShowCompletion");
        pathJointAngles.Clear();
        currentWaypointIndex = 0;
    }
}
