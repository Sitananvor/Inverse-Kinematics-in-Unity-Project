using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;

public class IK : MonoBehaviour
{
    [Header("Input Fields")]
    public TMP_InputField xf;
    public TMP_InputField yf;
    public TMP_InputField thetaf;
    public Toggle toggleElbowUp;
    public Toggle toggleElbowDown;

    [Header("Input Buttons")]
    public Button solveButton;
    public Button resetButton;

    [Header("Output IK")]
    public TextMeshProUGUI q1;
    public TextMeshProUGUI q2;
    public TextMeshProUGUI q3;

    [Header("Output Status/UI")]
    public TextMeshProUGUI statusText;
    public ShowTargetPoint ShowTargetPointScript;

    [Header("Link Lengths")]
    public float l1 = 1.5f;
    public float l2 = 2.5f;
    public float l3 = 2.0f;

    [Header("Joint Limits (deg)")]
    public float q1MinDeg = 0f;
    public float q1MaxDeg = 180f;
    public float q2MinDeg = -120f;
    public float q2MaxDeg = 120f;
    public float q3MinDeg = -135f;
    public float q3MaxDeg = 135f;

    [Header("Ground")]
    public Transform groundLine;

    [Header("Obstacle & Path Planning")]
    public Obstacle obstacleScript;
    public Toggle togglePathPlanning;
    public PathPlanning pathPlanningScript;

    [HideInInspector] public int UIShow = 0;
    [HideInInspector] public int simShow = 0;
    [HideInInspector] public float q1Rad, q2Rad, q3Rad;
    [HideInInspector] public float q1Deg, q2Deg, q3Deg;

    // Close form functions
    private Func<float> FK_PositionX;
    private Func<float> FK_PositionY;
    private Func<float> FK_Theta;
    private Func<float> J_dx_dq1;
    private Func<float> J_dx_dq2;
    private Func<float> J_dx_dq3;
    private Func<float> J_dy_dq1;
    private Func<float> J_dy_dq2;
    private Func<float> J_dy_dq3;
    private Func<float, float, float, float, float, float, float> J_Determinant;

    void Start()
    {
        BuildMDHClosedForm();
        solveButton.onClick.AddListener(OnSolveButtonClicked);
        resetButton.onClick.AddListener(OnResetButtonClicked);
    }

    void BuildMDHClosedForm()
    {
        FK_PositionX = () => l1 * Mathf.Cos(q1Rad) +
                              l2 * Mathf.Cos(q1Rad + q2Rad) +
                              l3 * Mathf.Cos(q1Rad + q2Rad + q3Rad);
        FK_PositionY = () => l1 * Mathf.Sin(q1Rad) +
                              l2 * Mathf.Sin(q1Rad + q2Rad) +
                              l3 * Mathf.Sin(q1Rad + q2Rad + q3Rad);
        FK_Theta = () => q1Rad + q2Rad + q3Rad;

        J_dx_dq1 = () =>
        {
            float q12 = q1Rad + q2Rad;
            float q123 = q12 + q3Rad;
            return -l1 * Mathf.Sin(q1Rad) - l2 * Mathf.Sin(q12) - l3 * Mathf.Sin(q123);
        };
        J_dx_dq2 = () =>
        {
            float q12 = q1Rad + q2Rad;
            float q123 = q12 + q3Rad;
            return -l2 * Mathf.Sin(q12) - l3 * Mathf.Sin(q123);
        };
        J_dx_dq3 = () => -l3 * Mathf.Sin(q1Rad + q2Rad + q3Rad);
        J_dy_dq1 = () =>
        {
            float q12 = q1Rad + q2Rad;
            float q123 = q12 + q3Rad;
            return l1 * Mathf.Cos(q1Rad) + l2 * Mathf.Cos(q12) + l3 * Mathf.Cos(q123);
        };
        J_dy_dq2 = () =>
        {
            float q12 = q1Rad + q2Rad;
            float q123 = q12 + q3Rad;
            return l2 * Mathf.Cos(q12) + l3 * Mathf.Cos(q123);
        };
        J_dy_dq3 = () => l3 * Mathf.Cos(q1Rad + q2Rad + q3Rad);

        J_Determinant = (J00, J01, J02, J10, J11, J12) =>
            J00 * (J11 - J12) - J01 * (J10 - J12) + J02 * (J10 - J11);
    }

    // Home Position + Reset Everything
    void OnResetButtonClicked()
    {
        q1Rad = q2Rad = q3Rad = 0f;
        q1Deg = q2Deg = q3Deg = 0f;

        q1.text = "0"; q2.text = "0"; q3.text = "0";

        xf.text = ""; yf.text = ""; thetaf.text = "";

        ShowTargetPointScript.targetPointReset();

        toggleElbowUp.isOn = true;
        toggleElbowDown.isOn = false;

        statusText.text = "Status: System Ready";
        statusText.color = Color.white;

        // Reset Obstacle
        obstacleScript.RemoveObstacle();
        togglePathPlanning.isOn = false;
        pathPlanningScript.ResetSystem();

        UIShow = 2;
        simShow = 2;
        Debug.Log("Home Configuration - All systems reset");
    }

    void OnSolveButtonClicked()
    {
        ShowTargetPointScript.targetPointReset();

        if (xf.text == "" || yf.text == "" || thetaf.text == "")
        {
            statusText.text = $"Status: Please complete the entry for target";
            statusText.color = Color.red;
            return;
        }

        float X = float.Parse(xf.text);
        float Y = float.Parse(yf.text);
        float thetaDeg = float.Parse(thetaf.text);

        if (!CheckReachability(X, Y)) return;

        ShowTargetPointScript.targetPointShow(X, Y);

        // Path Planning Mode
        if (togglePathPlanning.isOn)
        {
            simShow = 4;
            pathPlanningScript.PlanPathFromIK(X, Y, thetaDeg);
        }
        else
        {
            SolveIK_ClosedForm(X, Y, thetaDeg);
        }
    }

    bool CheckReachability(float X, float Y)
    {
        float distance = Mathf.Sqrt(X * X + Y * Y);
        float maxReach = l1 + l2 + l3;
        float minReach = Mathf.Abs(l1 - l2 - l3);

        if (distance > maxReach)
        {
            statusText.text = $"Status: Too far ({distance:F2} > {maxReach:F2})";
            statusText.color = Color.red;
            Debug.LogError("Too far");
            return false;
        }
        if (distance < minReach)
        {
            statusText.text = $"Status: Too close ({distance:F2} < {minReach:F2})";
            statusText.color = Color.red;
            Debug.LogError("Too close");
            return false;
        }
        Debug.Log($"Reachable");
        return true;
    }

    public bool SolveIK_ClosedForm(float X, float Y, float thetaDeg)
    {
        float thetaRad = thetaDeg * Mathf.Deg2Rad;

        float e1 = X - l3 * Mathf.Cos(thetaRad);
        float e2 = Y - l3 * Mathf.Sin(thetaRad);

        float cos_q2 = (e1 * e1 + e2 * e2 - l1 * l1 - l2 * l2) / (2f * l1 * l2);
        if (cos_q2 < -1f || cos_q2 > 1f)
        {
            statusText.text = $"Status: No solution (cos_q2={cos_q2:F2})";
            statusText.color = Color.red;
            Debug.LogError("cos(q2) out of range!");
            return false;
        }

        cos_q2 = Mathf.Clamp(cos_q2, -1f, 1f);
        float sinAbs = Mathf.Sqrt(1f - cos_q2 * cos_q2);

        float q2A = Mathf.Atan2(+sinAbs, cos_q2);
        float k1A = l1 + l2 * Mathf.Cos(q2A);
        float k2A = l2 * Mathf.Sin(q2A);
        float q1A = Mathf.Atan2(e2, e1) - Mathf.Atan2(k2A, k1A);
        float q3A = thetaRad - q1A - q2A;

        float exA = l1 * Mathf.Cos(q1A);
        float eyA = l1 * Mathf.Sin(q1A);
        float sA = X * eyA - Y * exA;
        bool isElbowUpA = sA > 0f;

        float q2B = Mathf.Atan2(-sinAbs, cos_q2);
        float k1B = l1 + l2 * Mathf.Cos(q2B);
        float k2B = l2 * Mathf.Sin(q2B);
        float q1B = Mathf.Atan2(e2, e1) - Mathf.Atan2(k2B, k1B);
        float q3B = thetaRad - q1B - q2B;

        float exB = l1 * Mathf.Cos(q1B);
        float eyB = l1 * Mathf.Sin(q1B);
        float sB = X * eyB - Y * exB;
        bool isElbowUpB = sB > 0f;

        float q1Up, q2Up, q3Up;
        float q1Down, q2Down, q3Down;

        if (isElbowUpA && !isElbowUpB)
        {
            q1Up = q1A; q2Up = q2A; q3Up = q3A;
            q1Down = q1B; q2Down = q2B; q3Down = q3B;
        }
        else if (!isElbowUpA && isElbowUpB)
        {
            q1Up = q1B; q2Up = q2B; q3Up = q3B;
            q1Down = q1A; q2Down = q2A; q3Down = q3A;
        }
        else
        {
            q1Up = q1A; q2Up = q2A; q3Up = q3A;
            q1Down = q1B; q2Down = q2B; q3Down = q3B;
        }

        if (toggleElbowUp.isOn && !toggleElbowDown.isOn)
        {
            q1Rad = q1Up;
            q2Rad = q2Up;
            q3Rad = q3Up;
            Debug.Log($"Elbow UP (q1={q1Rad * Mathf.Rad2Deg:F2}°, q2={q2Rad * Mathf.Rad2Deg:F2}°, q3={q3Rad * Mathf.Rad2Deg:F2}°)");
        }
        else if (!toggleElbowUp.isOn && toggleElbowDown.isOn)
        {
            q1Rad = q1Down;
            q2Rad = q2Down;
            q3Rad = q3Down;
            Debug.Log($"Elbow DOWN (q1={q1Rad * Mathf.Rad2Deg:F2}°, q2={q2Rad * Mathf.Rad2Deg:F2}°, q3={q3Rad * Mathf.Rad2Deg:F2}°)");
        }

        q1Deg = q1Rad * Mathf.Rad2Deg;
        q2Deg = q2Rad * Mathf.Rad2Deg;
        q3Deg = q3Rad * Mathf.Rad2Deg;

        if (q1Deg < q1MinDeg || q1Deg > q1MaxDeg)
        {
            statusText.text = $"Status: q1 limit exceeded ({q1Deg:F2}°)";
            statusText.color = Color.red;
            Debug.LogError("q1 limit exceeded");
            return false;
        }
        if (q2Deg < q2MinDeg || q2Deg > q2MaxDeg)
        {
            statusText.text = $"Status: q2 limit exceeded ({q2Deg:F2}°)";
            statusText.color = Color.red;
            Debug.LogError("q2 limit exceeded");
            return false;
        }
        if (q3Deg < q3MinDeg || q3Deg > q3MaxDeg)
        {
            statusText.text = $"Status: q3 limit exceeded ({q3Deg:F2}°)";
            statusText.color = Color.red;
            Debug.LogError("q3 limit exceeded");
            return false;
        }

        if (!CheckGroundCollision())
        {
            statusText.text = "Status: Collision with ground!";
            statusText.color = Color.red;
            return false;
        }

        if (!CheckSingularity())
        {
            statusText.text = "Status: Singularity!";
            statusText.color = Color.red;
            return false;
        }

        if (!VerifyFK_MDH(X, Y, thetaDeg))
        {
            statusText.text = "Status: Program calculation error. Sorry.";
            statusText.color = Color.red;
            return false;
        }

        statusText.text = "Status: Solution Found";
        statusText.color = new Color(0f, 0.65f, 0f);
        UIShow = 1;
        simShow = 1;

        q1.text = $"{q1Deg:F2}°";
        q2.text = $"{q2Deg:F2}°";
        q3.text = $"{q3Deg:F2}°";

        Invoke("ResetSimShow", 3.2f);
        return true;
    }

    bool CheckGroundCollision()
    {
        float groundY = groundLine.position.y;

        float j2_x = l1 * Mathf.Cos(q1Rad);
        float j2_y = l1 * Mathf.Sin(q1Rad);

        float q12 = q1Rad + q2Rad;
        float j3_x = j2_x + l2 * Mathf.Cos(q12);
        float j3_y = j2_y + l2 * Mathf.Sin(q12);

        float q123 = q12 + q3Rad;
        float ee_x = j3_x + l3 * Mathf.Cos(q123);
        float ee_y = j3_y + l3 * Mathf.Sin(q123);

        float collisionTolerance = 0.01f;
        float minAllowedY = groundY + collisionTolerance;

        if (j2_y < minAllowedY)
        {
            Debug.LogWarning($"Joint 2 collision! Y = {j2_y:F3} < {minAllowedY:F3}");
            return false;
        }
        if (j3_y < minAllowedY)
        {
            Debug.LogWarning($"Joint 3 collision! Y = {j3_y:F3} < {minAllowedY:F3}");
            return false;
        }
        if (ee_y < minAllowedY)
        {
            Debug.LogWarning($"End-Effector collision! Y = {ee_y:F3} < {minAllowedY:F3}");
            return false;
        }
        return true;
    }

    bool CheckSingularity()
    {
        float J00 = J_dx_dq1();
        float J01 = J_dx_dq2();
        float J02 = J_dx_dq3();
        float J10 = J_dy_dq1();
        float J11 = J_dy_dq2();
        float J12 = J_dy_dq3();

        float detJ = J_Determinant(J00, J01, J02, J10, J11, J12);
        Debug.Log($"det(J) = {detJ:F4}");

        float threshold = 0.0001f;
        if (Mathf.Abs(detJ) < threshold)
        {
            Debug.LogWarning($"Singularity: |det(J)| = {Mathf.Abs(detJ):F4}");
            return false;
        }
        Debug.Log($"No singularity");
        return true;
    }

    bool VerifyFK_MDH(float X, float Y, float thetaDeg)
    {
        float px = FK_PositionX();
        float py = FK_PositionY();
        float theta = FK_Theta();
        Debug.Log($"FK: px={px:F4}, py={py:F4}, theta={theta:F2}");

        float errorX = Mathf.Abs(px - X);
        float errorY = Mathf.Abs(py - Y);
        float errorTheta = Mathf.Abs(theta * Mathf.Rad2Deg - thetaDeg);
        Debug.Log($"Error: ΔX={errorX:F4}, ΔY={errorY:F4}, Δθ={errorTheta:F2}°");

        if (errorX < 0.001f && errorY < 0.001f && errorTheta < 0.01f)
        {
            Debug.Log("Verification passed");
            return true;
        }
        else
        {
            Debug.LogWarning("Verification failed");
            return false;
        }
    }

    void ResetSimShow() { simShow = 0; }
}