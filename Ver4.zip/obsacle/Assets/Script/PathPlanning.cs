using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class PathPlanning : MonoBehaviour
{
    [Header("References")]
    public IK ikScript;
    public Obstacle obstacleScript;
    public GridDrawer gridDrawer;
    
    [Header("Cubic Joint Controllers")]
    public CubicJointController joint1Controller;
    public CubicJointController joint2Controller;
    public CubicJointController joint3Controller;

    [Header("A* Settings")]
    public float stepSizeDeg = 15f;
    public float obstacleRadius = 0.5f;
    public int maxIterations = 10000;
    public float goalTolerance = 0.01f;

    [Header("Optimization")]
    public bool useAdaptiveStep = true;
    public int maxNeighbors = 16;

    [Header("Obstacle Avoidance")]
    public float obstaclePenalty = 5.0f;
    public float safetyMargin = 1.3f;

    [Header("Execution")]
    public float waypointDelay = 0.5f;

    // Variables
    private List<Vector3> pathJointAngles = new List<Vector3>();
    private int currentWaypointIndex = 0;
    private bool isExecutingPath = false;
    private Vector3 startJoints;
    private Vector3 goalJoints;
    
    private Vector2 cachedObstaclePos;
    private bool hasObstacleCache = false;

    // Node for A* Search
    private class Node
    {
        public Vector3 joints;
        public Node parent;
        public float gCost;
        public float hCost;
        public float fCost => gCost + hCost;

        public Node(Vector3 j, Node p, float g, float h)
        {
            joints = j;
            parent = p;
            gCost = g;
            hCost = h;
        }
    }

    public void ResetSystem()
    {
        ClearVisualization();
        ClearAllJointTrajectories();
        hasObstacleCache = false;
        cachedObstaclePos = Vector2.zero;
    }

    public bool CheckObstacleCollisionWithArm(Vector2 obstacleWorldPos, float radius)
    {
        float q1 = ikScript.q1Rad;
        float q2 = ikScript.q2Rad;
        float q3 = ikScript.q3Rad;

        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        var j2w = WorkspaceToWorld(j2);
        var j3w = WorkspaceToWorld(j3);
        var eew = WorkspaceToWorld(ee);

        bool collision = LineCircleIntersection(Vector2.zero, j2w, obstacleWorldPos, radius * safetyMargin) ||
                        LineCircleIntersection(j2w, j3w, obstacleWorldPos, radius * safetyMargin) ||
                        LineCircleIntersection(j3w, eew, obstacleWorldPos, radius * safetyMargin);

        if (collision)
        {
            Debug.LogWarning($"[PATH] ⚠ Obstacle collides with robot arm!");
        }

        return collision;
    }

    // ===== MAIN FUNCTION =====
    public void PlanPathFromIK(float goalX, float goalY, float goalThetaDeg)
    {
        // ลบเส้น trajectory ทั้งหมดก่อนเริ่มต้น
        ClearAllJointTrajectories();
        Debug.Log("[PATH] 🗑️ Cleared all joint trajectories before planning");
        
        ClearVisualization();

        // Cache obstacle
        if (obstacleScript != null && obstacleScript.obstacleHas > 0)
        {
            float obsGridX = obstacleScript.obstacleGridX;
            float obsGridY = obstacleScript.obstacleGridY;
            float spacing = gridDrawer.gridSpacing;
            
            cachedObstaclePos = new Vector2(-obsGridX * spacing, obsGridY * spacing);
            hasObstacleCache = true;

            if (CheckObstacleCollisionWithArm(cachedObstaclePos, obstacleRadius))
            {
                ikScript.statusText.text = "Status: ⚠ Obstacle blocks robot! Change position or reset";
                ikScript.statusText.color = Color.red;
                Debug.LogError("[PATH] Obstacle collision detected - cannot proceed");
                return;
            }

            Debug.Log($"[PATH] Obstacle cached at ({cachedObstaclePos.x:F2}, {cachedObstaclePos.y:F2})");
        }
        else
        {
            hasObstacleCache = false;
            Debug.Log("[PATH] No obstacle detected");
        }

        // Start configuration
        startJoints = new Vector3(ikScript.q1Rad, ikScript.q2Rad, ikScript.q3Rad);
        Debug.Log($"[PATH] Start: q1={startJoints.x*Mathf.Rad2Deg:F1}° q2={startJoints.y*Mathf.Rad2Deg:F1}° q3={startJoints.z*Mathf.Rad2Deg:F1}°");

        // Goal configuration
        if (!ikScript.SolveIK_ClosedForm(goalX, goalY, goalThetaDeg))
        {
            ikScript.statusText.text = "Status: IK Failed";
            ikScript.statusText.color = Color.red;
            return;
        }

        goalJoints = new Vector3(ikScript.q1Rad, ikScript.q2Rad, ikScript.q3Rad);
        Debug.Log($"[PATH] Goal: q1={goalJoints.x*Mathf.Rad2Deg:F1}° q2={goalJoints.y*Mathf.Rad2Deg:F1}° q3={goalJoints.z*Mathf.Rad2Deg:F1}°");

        // Run A*
        Debug.Log("[PATH] 🔍 Searching path...");
        if (RunAStar())
        {
            Debug.Log($"[PATH] ✓ Found path with {pathJointAngles.Count} waypoints");
            ExecutePath();
        }
        else
        {
            Debug.LogError("[PATH] ❌ Path not found - Moving to furthest safe point");
            if (pathJointAngles.Count > 0)
            {
                ExecutePath();
            }
            else
            {
                ikScript.statusText.text = "Status: No Path Found (Cannot move)";
                ikScript.statusText.color = Color.red;
            }
        }
    }

    // ลบเส้น trajectory ของทั้ง 3 joints
    private void ClearAllJointTrajectories()
    {
        if (joint1Controller != null)
        {
            joint1Controller.SendMessage("ClearTraject", SendMessageOptions.DontRequireReceiver);
        }
        if (joint2Controller != null)
        {
            joint2Controller.SendMessage("ClearTraject", SendMessageOptions.DontRequireReceiver);
        }
        if (joint3Controller != null)
        {
            joint3Controller.SendMessage("ClearTraject", SendMessageOptions.DontRequireReceiver);
        }
    }

    // ===== A* ALGORITHM =====
    private bool RunAStar()
    {
        pathJointAngles.Clear();

        var openSet = new SortedSet<Node>(new NodeComparer());
        var openDict = new Dictionary<Vector3Int, Node>();
        var closedSet = new HashSet<Vector3Int>();

        var startNode = new Node(startJoints, null, 0f, Heuristic(startJoints, goalJoints));
        openSet.Add(startNode);
        openDict[Discretize(startJoints)] = startNode;

        int iterations = 0;
        var bestNode = startNode;
        float bestDist = float.MaxValue;

        while (openSet.Count > 0 && iterations < maxIterations)
        {
            iterations++;

            var current = openSet.Min;
            openSet.Remove(current);
            
            var currentDisc = Discretize(current.joints);
            openDict.Remove(currentDisc);

            float distToGoal = Vector3.Distance(current.joints, goalJoints);
            if (distToGoal < bestDist)
            {
                bestDist = distToGoal;
                bestNode = current;
            }

            if (distToGoal < goalTolerance)
            {
                Debug.Log($"[PATH] ✓ Reached goal in {iterations} iterations");
                ReconstructPath(current);
                return true;
            }

            closedSet.Add(currentDisc);

            // Adaptive step size
            float stepSize = stepSizeDeg;
            if (useAdaptiveStep)
            {
                float factor = Mathf.Clamp01(distToGoal / 1.5f);
                stepSize = Mathf.Lerp(8f, stepSizeDeg, factor);
            }

            var neighbors = GetNeighborsImproved(current.joints, stepSize);
            
            foreach (var neighbor in neighbors)
            {
                var neighborDisc = Discretize(neighbor);
                
                if (closedSet.Contains(neighborDisc))
                    continue;

                if (!IsValid(neighbor))
                    continue;

                float moveCost = Vector3.Distance(current.joints, neighbor);
                float gCost = current.gCost + moveCost;
                
                float hCost = HeuristicWithObstacle(neighbor, goalJoints);

                if (openDict.TryGetValue(neighborDisc, out var existing))
                {
                    if (gCost < existing.gCost)
                    {
                        openSet.Remove(existing);
                        existing.gCost = gCost;
                        existing.hCost = hCost;
                        existing.parent = current;
                        openSet.Add(existing);
                    }
                }
                else
                {
                    var newNode = new Node(neighbor, current, gCost, hCost);
                    openSet.Add(newNode);
                    openDict[neighborDisc] = newNode;
                }
            }
        }

        if (bestNode != startNode)
        {
            float distFromStart = Vector3.Distance(bestNode.joints, startJoints);
            if (distFromStart > 0.1f)
            {
                Debug.LogWarning($"[PATH] ⚠ Using partial path (reached {bestDist:F3}m from goal)");
                ReconstructPath(bestNode);
                ikScript.statusText.text = $"Status: Partial Path Found (stopped {bestDist:F2}m before goal)";
                ikScript.statusText.color = Color.yellow;
                return false;
            }
        }

        return false;
    }

    private class NodeComparer : IComparer<Node>
    {
        public int Compare(Node x, Node y)
        {
            if (x == null || y == null) return x == null ? 1 : -1;
            int f = x.fCost.CompareTo(y.fCost);
            if (f != 0) return f;
            int h = x.hCost.CompareTo(y.hCost);
            if (h != 0) return h;
            return x.GetHashCode().CompareTo(y.GetHashCode());
        }
    }

    // ===== HEURISTIC =====
    private float Heuristic(Vector3 from, Vector3 to)
    {
        return Vector3.Distance(from, to);
    }

    private float HeuristicWithObstacle(Vector3 config, Vector3 goal)
    {
        float baseCost = Vector3.Distance(config, goal);
        
        if (!hasObstacleCache)
            return baseCost * 1.1f;

        float minDistToObstacle = GetMinDistanceToObstacle(config);
        
        float obstacleCost = 0f;
        if (minDistToObstacle < obstacleRadius * safetyMargin * 2f)
        {
            float proximity = 1f - Mathf.Clamp01(minDistToObstacle / (obstacleRadius * safetyMargin * 2f));
            obstacleCost = proximity * obstaclePenalty;
        }
        
        return baseCost * 1.1f + obstacleCost;
    }

    private float GetMinDistanceToObstacle(Vector3 joints)
    {
        if (!hasObstacleCache)
            return float.MaxValue;

        float q1 = joints.x, q2 = joints.y, q3 = joints.z;

        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        var j2w = WorkspaceToWorld(j2);
        var j3w = WorkspaceToWorld(j3);
        var eew = WorkspaceToWorld(ee);

        float dist1 = DistanceToLineSegment(Vector2.zero, j2w, cachedObstaclePos);
        float dist2 = DistanceToLineSegment(j2w, j3w, cachedObstaclePos);
        float dist3 = DistanceToLineSegment(j3w, eew, cachedObstaclePos);

        return Mathf.Min(dist1, Mathf.Min(dist2, dist3));
    }

    private float DistanceToLineSegment(Vector2 start, Vector2 end, Vector2 point)
    {
        var line = end - start;
        float len = line.magnitude;
        if (len < 0.001f) return Vector2.Distance(start, point);

        float t = Mathf.Clamp01(Vector2.Dot(point - start, line) / (len * len));
        var projection = start + t * line;
        return Vector2.Distance(point, projection);
    }

    private Vector3Int Discretize(Vector3 config)
    {
        return new Vector3Int(
            Mathf.RoundToInt(config.x * Mathf.Rad2Deg * 2f),
            Mathf.RoundToInt(config.y * Mathf.Rad2Deg * 2f),
            Mathf.RoundToInt(config.z * Mathf.Rad2Deg * 2f)
        );
    }

    // ===== NEIGHBORS GENERATION =====
    private List<Vector3> GetNeighborsImproved(Vector3 config, float stepSize)
    {
        var neighbors = new List<Vector3>();
        float step = stepSize * Mathf.Deg2Rad;
        
        float[] steps = { -step, -step * 0.5f, 0f, step * 0.5f, step };

        foreach (float dq1 in steps)
        {
            foreach (float dq2 in steps)
            {
                foreach (float dq3 in steps)
                {
                    if (dq1 == 0 && dq2 == 0 && dq3 == 0) continue;

                    neighbors.Add(new Vector3(config.x + dq1, config.y + dq2, config.z + dq3));
                }
            }
        }

        return neighbors
            .OrderBy(n => {
                float distToGoal = Vector3.Distance(n, goalJoints);
                float distToObs = hasObstacleCache ? GetMinDistanceToObstacle(n) : 100f;
                return distToGoal - (distToObs * 0.1f);
            })
            .Take(maxNeighbors)
            .ToList();
    }

    // ===== COLLISION CHECKING =====
    private bool IsValid(Vector3 joints)
    {
        float q1 = joints.x, q2 = joints.y, q3 = joints.z;
        float q1D = q1 * Mathf.Rad2Deg, q2D = q2 * Mathf.Rad2Deg, q3D = q3 * Mathf.Rad2Deg;

        if (q1D < ikScript.q1MinDeg || q1D > ikScript.q1MaxDeg) return false;
        if (q2D < ikScript.q2MinDeg || q2D > ikScript.q2MaxDeg) return false;
        if (q3D < ikScript.q3MinDeg || q3D > ikScript.q3MaxDeg) return false;

        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        if (j2.y < 0.01f || j3.y < 0.01f || ee.y < 0.01f) return false;

        if (hasObstacleCache)
        {
            var j2w = WorkspaceToWorld(j2);
            var j3w = WorkspaceToWorld(j3);
            var eew = WorkspaceToWorld(ee);
            
            float safeRadius = obstacleRadius * safetyMargin;
            
            if (LineCircleIntersection(Vector2.zero, j2w, cachedObstaclePos, safeRadius)) return false;
            if (LineCircleIntersection(j2w, j3w, cachedObstaclePos, safeRadius)) return false;
            if (LineCircleIntersection(j3w, eew, cachedObstaclePos, safeRadius)) return false;
        }

        return true;
    }

    private bool CheckCollisionNow(Vector3 joints)
    {
        if (!hasObstacleCache)
            return false;

        float q1 = joints.x, q2 = joints.y, q3 = joints.z;

        var j2 = new Vector2(ikScript.l1 * Mathf.Cos(q1), ikScript.l1 * Mathf.Sin(q1));
        float q12 = q1 + q2;
        var j3 = new Vector2(j2.x + ikScript.l2 * Mathf.Cos(q12), j2.y + ikScript.l2 * Mathf.Sin(q12));
        float q123 = q12 + q3;
        var ee = new Vector2(j3.x + ikScript.l3 * Mathf.Cos(q123), j3.y + ikScript.l3 * Mathf.Sin(q123));

        var j2w = WorkspaceToWorld(j2);
        var j3w = WorkspaceToWorld(j3);
        var eew = WorkspaceToWorld(ee);
        
        float safeRadius = obstacleRadius * safetyMargin;
        
        return LineCircleIntersection(Vector2.zero, j2w, cachedObstaclePos, safeRadius) ||
               LineCircleIntersection(j2w, j3w, cachedObstaclePos, safeRadius) ||
               LineCircleIntersection(j3w, eew, cachedObstaclePos, safeRadius);
    }

    // ===== PATH RECONSTRUCTION =====
    private void ReconstructPath(Node goalNode)
    {
        pathJointAngles.Clear();
        
        var current = goalNode;
        while (current != null)
        {
            pathJointAngles.Insert(0, current.joints);
            current = current.parent;
        }

        Debug.Log($"[PATH] Reconstructed {pathJointAngles.Count} waypoints");
    }

    // ===== PATH EXECUTION =====
    private void ExecutePath()
    {
        ikScript.statusText.text = "Status: Executing...";
        ikScript.statusText.color = Color.cyan;
        currentWaypointIndex = 0;
        isExecutingPath = true;
        ExecuteNextWaypoint();
    }

    private void ExecuteNextWaypoint()
    {
        if (!isExecutingPath || currentWaypointIndex >= pathJointAngles.Count)
        {
            isExecutingPath = false;
            
            if (currentWaypointIndex > 0)
            {
                float distToGoal = Vector3.Distance(pathJointAngles[currentWaypointIndex - 1], goalJoints);
                if (distToGoal < goalTolerance * 2f)
                {
                    ikScript.statusText.text = "Status: Complete! ✓";
                    ikScript.statusText.color = Color.green;
                }
                else
                {
                    ikScript.statusText.text = "Status: Partial Path Complete ⚠";
                    ikScript.statusText.color = Color.yellow;
                }
            }
            return;
        }

        var joints = pathJointAngles[currentWaypointIndex];

        if (CheckCollisionNow(joints))
        {
            isExecutingPath = false;
            ikScript.statusText.text = "Status: ⚠ Collision Detected! Stopped";
            ikScript.statusText.color = Color.red;
            Debug.LogWarning($"[PATH] ⚠ Collision at waypoint {currentWaypointIndex}");
            return;
        }

        ikScript.q1Rad = joints.x;
        ikScript.q2Rad = joints.y;
        ikScript.q3Rad = joints.z;
        ikScript.q1Deg = joints.x * Mathf.Rad2Deg;
        ikScript.q2Deg = joints.y * Mathf.Rad2Deg;
        ikScript.q3Deg = joints.z * Mathf.Rad2Deg;

        ikScript.q1.text = $"{ikScript.q1Deg:F1}°";
        ikScript.q2.text = $"{ikScript.q2Deg:F1}°";
        ikScript.q3.text = $"{ikScript.q3Deg:F1}°";
        
        ikScript.statusText.text = $"Status: {currentWaypointIndex + 1}/{pathJointAngles.Count}";
        ikScript.statusText.color = Color.cyan;
        
        ikScript.UIShow = 1;
        ikScript.simShow = 1;

        currentWaypointIndex++;

        if (currentWaypointIndex < pathJointAngles.Count)
            Invoke("ExecuteNextWaypoint", waypointDelay);
        else
            Invoke("ShowCompletion", waypointDelay);
    }

    private void ShowCompletion()
    {
        float distToGoal = Vector3.Distance(pathJointAngles[pathJointAngles.Count - 1], goalJoints);
        if (distToGoal < goalTolerance * 2f)
        {
            ikScript.statusText.text = "Status: Complete! ✓";
            ikScript.statusText.color = Color.green;
        }
        else
        {
            ikScript.statusText.text = "Status: Partial Path Complete ⚠";
            ikScript.statusText.color = Color.yellow;
        }
    }

    // ===== UTILITIES =====
    private Vector2 WorkspaceToWorld(Vector2 ws)
    {
        float spacing = gridDrawer.gridSpacing;
        return new Vector2(-ws.x * spacing, ws.y * spacing);
    }

    private bool LineCircleIntersection(Vector2 start, Vector2 end, Vector2 center, float radius)
    {
        var d = end - start;
        var f = start - center;

        float a = Vector2.Dot(d, d);
        float b = 2f * Vector2.Dot(f, d);
        float c = Vector2.Dot(f, f) - radius * radius;

        float disc = b * b - 4f * a * c;
        if (disc < 0) return false;

        disc = Mathf.Sqrt(disc);
        float t1 = (-b - disc) / (2f * a);
        float t2 = (-b + disc) / (2f * a);

        return (t1 >= 0 && t1 <= 1) || (t2 >= 0 && t2 <= 1);
    }

    private void ClearVisualization()
    {
        isExecutingPath = false;
        CancelInvoke("ExecuteNextWaypoint");
        CancelInvoke("ShowCompletion");
        pathJointAngles.Clear();
        currentWaypointIndex = 0;
    }
}