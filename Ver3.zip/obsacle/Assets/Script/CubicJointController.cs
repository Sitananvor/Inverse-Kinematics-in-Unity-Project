using UnityEngine;
using System.Collections.Generic;

public class CubicJointController : MonoBehaviour
{
    [Header("Joint Settings")]
    public int jointNumber = 1;
    public float totalMoveTime = 3f;    // Time to complete one trajectory (seconds)

    [Header("Line Renderer Settings")]
    public float lineWidth = 0.05f;
    public int maxTrajectPoints = 500;
    public Transform linkEndPoint;

    [Header("IK Script")]
    public IK ik;

    // Cubic polynomial coefficients
    private float a0, a1, a2, a3;
    private float currentTime = 0f;
    private bool isMoving = false;

    // Joint angles (radians)
    private float startAngle;
    private float endAngle;
    
    // LineRenderer for drawing trajectory
    private LineRenderer lineRenderer;
    private List<Vector3> trajectPoints = new List<Vector3>();

    // Store previous simShow state
    private int lastSimShow = 0;

    void Start()
    {
        // Setup LineRenderer
        SetupLineRenderer();

        // Initial home position (0 rad)
        startAngle = 0f;
        endAngle = 0f;
        transform.localRotation = Quaternion.Euler(0, 0, 0);
    }

    void Update()
    {
        // Home mode
        if (ik.simShow == 2)
        {
            // When entering home mode, clear trajectory line once
            if (lastSimShow != 2)
            {
                ClearTraject();
            }

            // Reset joint to home pose
            ResetToHome();
            lastSimShow = 2;
            return;
        }

        // Detect new Solve command (simShow changes to 1)
        if (ik.simShow == 1 && lastSimShow != 1)
        {
            ClearTraject();
        }
        lastSimShow = ik.simShow;

        // IK mode: move joint to target angle
        if (ik.simShow == 1)
        {
            // Get target angle from IK (radians)
            float targetAngleRad = GetTargetAngleFromIK();

            // Read current angle from transform and convert to radians
            float currentAngleDeg = transform.localEulerAngles.y;
            if (currentAngleDeg > 180f) currentAngleDeg -= 360f; // 0–360° → -180–180°
            float currentAngleRad = -currentAngleDeg * Mathf.Deg2Rad;  // Invert and convert to radians

            // Start new trajectory if target angle is different
            if (Mathf.Abs(targetAngleRad - currentAngleRad) > 0.001f && !isMoving)
            {
                startAngle = currentAngleRad;
                endAngle = targetAngleRad;
                ComputeCoefficients();
                StartMovement();
            }

            // Update motion along trajectory
            if (isMoving)
            {
                UpdateTrajectoryMotion();
            }

            return;
        }
    }

    // Update motion along the cubic trajectory and apply rotation
    void UpdateTrajectoryMotion()
    {
        // Advance time
        currentTime += Time.deltaTime;
        if (currentTime >= totalMoveTime)
        {
            currentTime = totalMoveTime;
            isMoving = false;
        }

        // Calculate angle in radians using cubic polynomial
        // θ(t) = a0 + a1*t + a2*t² + a3*t³ 
        float angleRad = a0
                       + a1 * currentTime
                       + a2 * Mathf.Pow(currentTime, 2)
                       + a3 * Mathf.Pow(currentTime, 3);

        // Convert to degrees for Unity rotation
        float angleDeg = angleRad * Mathf.Rad2Deg;

        // Apply rotation 
        transform.localRotation = Quaternion.Euler(0, -angleDeg, 0);

        // Add current end point position to trajectory
        AddTrajectPoint();
    }

    // Get target joint angle from IK script
    float GetTargetAngleFromIK()
    {
        switch (jointNumber)
        {
            case 1:
                return ik.q1Rad;
            case 2:
                return ik.q2Rad;
            case 3:
                return ik.q3Rad;
            default:
                return 0f;
        }
    }

    // Compute cubic polynomial coefficients ; Boundary conditions: θ(0)=θ0, θ(tf)=θf, θ̇(0)=0, θ̇(tf)=0
    void ComputeCoefficients()
    {
        a0 = startAngle;
        a1 = 0f;
        a2 = 3f * (endAngle - startAngle) / (totalMoveTime * totalMoveTime);
        a3 = -2f * (endAngle - startAngle) / (totalMoveTime * totalMoveTime * totalMoveTime);

        Debug.Log(
            $"Joint {jointNumber}: Coeffs from {startAngle:F4} rad ({startAngle * Mathf.Rad2Deg:F2}°) " +
            $"to {endAngle:F4} rad ({endAngle * Mathf.Rad2Deg:F2}°)");
    }

    // Start motion along the cubic trajectory
    void StartMovement()
    {
        currentTime = 0f;
        isMoving = true;
        Debug.Log(
            $"Joint {jointNumber}: Start motion {startAngle:F4} rad → {endAngle:F4} rad ");
    }

    // Reset joint to home position
    void ResetToHome()
    {
        isMoving = false;
        currentTime = 0f;
        startAngle = 0f;
        endAngle = 0f;
        transform.localRotation = Quaternion.Euler(0, 0, 0);
    }

    // Setup LineRenderer for trajectory visualization
    void SetupLineRenderer()
    {
        lineRenderer = gameObject.GetComponent<LineRenderer>();
        if (lineRenderer == null)
        {
            lineRenderer = gameObject.AddComponent<LineRenderer>();
        }

        // Choose color by joint index
        Color lineColor = Color.white;
        switch (jointNumber)
        {
            case 1: lineColor = new Color(1f, 0.5f, 0.5f, 0.7f); break; // Light red
            case 2: lineColor = new Color(0.5f, 1f, 0.5f, 0.7f); break; // Light green
            case 3: lineColor = new Color(0.5f, 0.8f, 1f, 0.7f); break; // Light blue
        }

        lineRenderer.startColor = lineColor;
        lineRenderer.endColor = lineColor;
        lineRenderer.startWidth = lineWidth;
        lineRenderer.endWidth = lineWidth;
        lineRenderer.positionCount = 0;
        lineRenderer.useWorldSpace = true;
        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
    }

    // Add current link end point position to trajectory
    void AddTrajectPoint()
    {
        Vector3 currentPos = linkEndPoint.position;

        // Add first point or when moved enough from last point
        if (trajectPoints.Count == 0 || Vector3.Distance(currentPos, trajectPoints[trajectPoints.Count - 1]) > 0.01f)
        {
            trajectPoints.Add(currentPos);

            // Limit number of trajectory points
            if (trajectPoints.Count > maxTrajectPoints)
            {
                trajectPoints.RemoveAt(0);
            }

            UpdateLineRenderer();
        }
    }

    // Update LineRenderer positions from trajectory points
    void UpdateLineRenderer()
    {
        if (lineRenderer != null && trajectPoints.Count > 0)
        {
            lineRenderer.positionCount = trajectPoints.Count;
            lineRenderer.SetPositions(trajectPoints.ToArray());
        }
        else if (lineRenderer != null)
        {
            lineRenderer.positionCount = 0;
        }
    }

    // Clear trajectory points and line
    void ClearTraject()
    {
        trajectPoints.Clear();
        UpdateLineRenderer();
    }
}